// ─── Icon set (inline SVG, Lucide-ish) ─────────────────────────────────────
const Icon = ({ name, size = 16, stroke = 1.75, className = "", style }) => {
  const s = size;
  const common = {
    width: s, height: s, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor",
    strokeWidth: stroke, strokeLinecap: "round", strokeLinejoin: "round",
    className, style
  };
  switch (name) {
    case "dashboard": return <svg {...common}><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>;
    case "transactions": return <svg {...common}><path d="M7 10h14M7 10l4-4M7 10l4 4M17 14H3M17 14l-4-4M17 14l-4 4"/></svg>;
    case "agents": return <svg {...common}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
    case "reports": return <svg {...common}><path d="M3 3v18h18"/><path d="M7 16l4-5 4 3 5-7"/></svg>;
    case "settings": return <svg {...common}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.9-2.9l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.9-2.9l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.9 2.9l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>;
    case "upload": return <svg {...common}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>;
    case "search": return <svg {...common}><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
    case "bell": return <svg {...common}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>;
    case "moon": return <svg {...common}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>;
    case "sun": return <svg {...common}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>;
    case "logout": return <svg {...common}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>;
    case "chevron-down": return <svg {...common}><polyline points="6 9 12 15 18 9"/></svg>;
    case "chevron-right": return <svg {...common}><polyline points="9 18 15 12 9 6"/></svg>;
    case "chevron-left": return <svg {...common}><polyline points="15 18 9 12 15 6"/></svg>;
    case "filter": return <svg {...common}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>;
    case "download": return <svg {...common}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>;
    case "plus": return <svg {...common}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
    case "x": return <svg {...common}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
    case "check": return <svg {...common}><polyline points="20 6 9 17 4 12"/></svg>;
    case "more": return <svg {...common}><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>;
    case "edit": return <svg {...common}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>;
    case "eye": return <svg {...common}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
    case "calendar": return <svg {...common}><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>;
    case "phone": return <svg {...common}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>;
    case "user": return <svg {...common}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
    case "users": return <svg {...common}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
    case "wallet": return <svg {...common}><path d="M20 12V8H6a2 2 0 0 1 0-4h12v4"/><path d="M20 12v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h14"/><circle cx="16" cy="13" r="1"/></svg>;
    case "trending-up": return <svg {...common}><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>;
    case "trending-down": return <svg {...common}><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>;
    case "arrow-up": return <svg {...common}><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>;
    case "arrow-down": return <svg {...common}><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>;
    case "arrow-right": return <svg {...common}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>;
    case "menu": return <svg {...common}><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>;
    case "sidebar": return <svg {...common}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>;
    case "external": return <svg {...common}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>;
    case "copy": return <svg {...common}><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>;
    case "info": return <svg {...common}><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>;
    case "alert": return <svg {...common}><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;
    case "check-circle": return <svg {...common}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>;
    case "clock": return <svg {...common}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>;
    case "trash": return <svg {...common}><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>;
    case "shield": return <svg {...common}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>;
    case "zap": return <svg {...common}><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>;
    case "message": return <svg {...common}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>;
    case "send": return <svg {...common}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>;
    case "refresh": return <svg {...common}><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>;
    case "lock": return <svg {...common}><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>;
    default: return <svg {...common}><circle cx="12" cy="12" r="9"/></svg>;
  }
};

// ─── Sidebar ─────────────────────────────────────────────────────────────────
const Sidebar = ({ currentPath, onNavigate, collapsed, role, onCollapseToggle, user, onLogout }) => {
  const adminNav = [
    { path: "dashboard", label: "Dashboard", icon: "dashboard" },
    { path: "transactions", label: "Transactions", icon: "transactions" },
    { path: "agents", label: "Agents", icon: "agents" },
    { path: "reports", label: "Reports", icon: "reports" },
  ];
  const agentNav = [
    { path: "dashboard", label: "Dashboard", icon: "dashboard" },
    { path: "my-transactions", label: "My Transactions", icon: "transactions" },
    { path: "my-reports", label: "My Reports", icon: "reports" },
  ];
  const nav = role === "admin" ? adminNav : agentNav;
  const utility = [
    { path: "upload", label: "Upload SMS", icon: "upload" },
    { path: "settings", label: "Settings", icon: "settings" },
  ];

  return (
    <aside className="sidebar">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 6px 14px" }}>
        <div className="brand-mark">
          <div className="brand-glyph">b</div>
          {!collapsed && <span>Cashout Sync</span>}
        </div>
        {!collapsed && (
          <button className="btn-ghost btn btn-icon btn-sm" onClick={onCollapseToggle} title="Collapse">
            <Icon name="sidebar" size={15} />
          </button>
        )}
      </div>

      {!collapsed && <div style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-dim)", padding: "10px 10px 6px" }}>Main</div>}
      {nav.map(it => (
        <div key={it.path} className={"nav-item" + (currentPath === it.path ? " active" : "")} onClick={() => onNavigate(it.path)}>
          <Icon name={it.icon} className="ni-icon" />
          {!collapsed && <span>{it.label}</span>}
        </div>
      ))}

      {!collapsed && <div style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-dim)", padding: "14px 10px 6px" }}>Workspace</div>}
      {utility.map(it => (
        <div key={it.path} className={"nav-item" + (currentPath === it.path ? " active" : "")} onClick={() => onNavigate(it.path)}>
          <Icon name={it.icon} className="ni-icon" />
          {!collapsed && <span>{it.label}</span>}
        </div>
      ))}

      <div style={{ flex: 1 }} />

      {collapsed ? (
        <button className="btn btn-ghost btn-icon" onClick={onCollapseToggle} title="Expand">
          <Icon name="sidebar" size={15} />
        </button>
      ) : (
        <div style={{ borderTop: "1px solid var(--divider)", margin: "8px -12px 0", padding: "12px 12px 0" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "4px 6px" }}>
            <div className="avatar">{user.name.split(" ").map(s => s[0]).slice(0,2).join("")}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.name}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "capitalize" }}>{user.role}</div>
            </div>
            <button className="btn btn-ghost btn-icon btn-sm" onClick={onLogout} title="Logout">
              <Icon name="logout" size={14} />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};

// ─── Topbar ──────────────────────────────────────────────────────────────────
const Topbar = ({ title, subtitle, onToggleTheme, theme, onSwitchRole, role, children }) => {
  const [showRoleMenu, setShowRoleMenu] = React.useState(false);
  return (
    <div className="topbar">
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.02em" }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 1 }}>{subtitle}</div>}
      </div>
      {children}
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <div style={{ position: "relative" }}>
          <button className="chip" onClick={() => setShowRoleMenu(s => !s)} style={{ textTransform: "capitalize" }}>
            <span className="live-dot" />
            {role}
            <Icon name="chevron-down" size={12} />
          </button>
          {showRoleMenu && (
            <>
              <div style={{ position: "fixed", inset: 0, zIndex: 30 }} onClick={() => setShowRoleMenu(false)} />
              <div style={{ position: "absolute", right: 0, top: "calc(100% + 6px)", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--r-md)", boxShadow: "var(--shadow-lg)", minWidth: 200, padding: 6, zIndex: 40 }}>
                <div style={{ fontSize: 11, color: "var(--text-muted)", padding: "6px 10px 8px", textTransform: "uppercase", letterSpacing: "0.06em" }}>Switch role (demo)</div>
                {["admin","agent"].map(r => (
                  <div key={r} className="nav-item" style={{ marginBottom: 0 }} onClick={() => { onSwitchRole(r); setShowRoleMenu(false); }}>
                    <Icon name={r === "admin" ? "shield" : "user"} className="ni-icon" size={15} />
                    <span style={{ textTransform: "capitalize" }}>{r}</span>
                    {role === r && <Icon name="check" size={14} style={{ marginLeft: "auto", color: "var(--brand)" }} />}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
        <button className="btn btn-ghost btn-icon" onClick={onToggleTheme} title="Toggle theme">
          <Icon name={theme === "dark" ? "sun" : "moon"} size={15} />
        </button>
        <button className="btn btn-ghost btn-icon" title="Notifications">
          <Icon name="bell" size={15} />
        </button>
      </div>
    </div>
  );
};

// ─── Status badge ────────────────────────────────────────────────────────────
const StatusBadge = ({ status, size = "md" }) => {
  const map = {
    paid: { cls: "pill-success", label: "Paid" },
    received: { cls: "pill-warning", label: "Received" },
    active: { cls: "pill-info", label: "Active" },
    inactive: { cls: "pill-muted", label: "Inactive" },
  };
  const m = map[status] || { cls: "pill-muted", label: status };
  return (
    <span className={"pill " + m.cls} style={size === "sm" ? { fontSize: 10, padding: "2px 7px" } : undefined}>
      <span className="pill-dot" />{m.label}
    </span>
  );
};

// ─── StatCard ────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, currency, trend, trendDir, sparkData, icon, loading }) => {
  if (loading) {
    return (
      <div className="stat">
        <div className="skel" style={{ width: 80, height: 11, marginBottom: 12 }} />
        <div className="skel" style={{ width: 140, height: 28 }} />
        <div className="skel" style={{ width: 60, height: 16, marginTop: 8 }} />
      </div>
    );
  }
  return (
    <div className="stat">
      <div className="stat-label">{label}</div>
      <div className="stat-value">
        {currency && <span className="stat-cur">৳</span>}
        <span>{value}</span>
      </div>
      {trend != null && (
        <div className={"stat-trend " + (trendDir === "down" ? "down" : "up")}>
          <Icon name={trendDir === "down" ? "arrow-down" : "arrow-up"} size={11} stroke={2.5} />
          {trend}
        </div>
      )}
      {icon && <div className="stat-icon"><Icon name={icon} size={16} /></div>}
      {sparkData && <Sparkline data={sparkData} className="stat-spark" />}
    </div>
  );
};

// ─── Sparkline ───────────────────────────────────────────────────────────────
const Sparkline = ({ data, className, color = "var(--brand)" }) => {
  if (!data || data.length < 2) return null;
  const w = 110, h = 44;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const pad = 4;
  const step = (w - pad*2) / (data.length - 1);
  const norm = (v) => h - pad - ((v - min) / (max - min || 1)) * (h - pad*2);
  const points = data.map((v, i) => `${pad + i*step},${norm(v)}`).join(" ");
  const area = `M ${pad},${h} L ${points.split(" ").join(" L ")} L ${w-pad},${h} Z`;
  return (
    <svg className={className} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id="sparkgrad" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.5"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill="url(#sparkgrad)"/>
      <polyline fill="none" stroke={color} strokeWidth="1.5" points={points} />
    </svg>
  );
};

Object.assign(window, { Icon, Sidebar, Topbar, StatusBadge, StatCard, Sparkline });
