// ─── Reports (admin) ──────────────────────────────────────────────────────────
const ReportsPage = ({ role, currentUser, onOpenAgent }) => {
  const [period, setPeriod] = React.useState("monthly");
  const [agentFilter, setAgentFilter] = React.useState("all");

  const allTx = role === "admin" ? window.TRANSACTIONS : window.TRANSACTIONS.filter(t => t.agentId === currentUser.id);
  const tx = agentFilter === "all" ? allTx : allTx.filter(t => t.agentId === agentFilter);

  // Period-aware series
  const series = period === "daily" ? dailySeries(tx, 14) :
                 period === "weekly" ? dailySeries(tx, 14) :
                 monthlySeries(tx, 6);

  const paid = tx.filter(t => t.status === "paid");
  const totalPaid = paid.reduce((s,t)=>s+parseFloat(t.amount), 0);
  const avgAmount = paid.length ? totalPaid / paid.length : 0;

  const agentPerf = role === "admin" ? (() => {
    return window.AGENTS.map(a => {
      const my = allTx.filter(t => t.agentId === a.id && t.status === "paid");
      return {
        agent: a,
        total: my.reduce((s,t) => s+parseFloat(t.amount), 0),
        count: my.length,
      };
    }).sort((a,b) => b.total - a.total);
  })() : null;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">{role === "admin" ? "Reports" : "My reports"}</h1>
          <div className="page-sub">Performance breakdown — pick a period to slice</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn"><Icon name="download" size={13} /> Export PDF</button>
        </div>
      </div>

      <div className="card" style={{ padding: 14, marginBottom: 14, display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <div>
          <div className="label" style={{ marginBottom: 4 }}>Period</div>
          <div className="seg">
            {[["daily","Daily"],["weekly","Weekly"],["monthly","Monthly"],["custom","Custom"]].map(([k,l]) =>
              <button key={k} className={period === k ? "on" : ""} onClick={() => setPeriod(k)}>{l}</button>
            )}
          </div>
        </div>
        {role === "admin" && (
          <div>
            <div className="label" style={{ marginBottom: 4 }}>Agent</div>
            <select className="input" style={{ width: 200, padding: "6px 28px 6px 10px", fontSize: 12 }} value={agentFilter} onChange={e => setAgentFilter(e.target.value)}>
              <option value="all">All agents</option>
              {window.AGENTS.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
        )}
        {period === "custom" && (
          <>
            <div>
              <div className="label" style={{ marginBottom: 4 }}>From</div>
              <input className="input" type="date" defaultValue="2026-04-13" style={{ width: 160 }} />
            </div>
            <div>
              <div className="label" style={{ marginBottom: 4 }}>To</div>
              <input className="input" type="date" defaultValue="2026-05-13" style={{ width: 160 }} />
            </div>
          </>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 14 }}>
        <StatCard label="Total paid" value={fmtAmountShort(totalPaid).replace("৳ ","")} currency icon="wallet" trend="+12.4%" trendDir="up" />
        <StatCard label="Total transactions" value={tx.length.toLocaleString()} icon="transactions" trend={`${paid.length} paid`} trendDir="up" />
        <StatCard label="Average amount" value={fmtAmountShort(avgAmount).replace("৳ ","")} currency icon="trending-up" trend="+3.1%" trendDir="up" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Revenue trend</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{period === "monthly" ? "Last 6 months" : "Last 14 days"}</div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <LineAreaChart data={series} height={260} valueKey="paidAmount" labelKey={period === "monthly" ? "label" : "shortLabel"} />
          </div>
        </div>
        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Transaction volume</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Count by {period === "monthly" ? "month" : "day"}</div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <BarChart data={series} height={260} valueKey="count" labelKey={period === "monthly" ? "label" : "shortLabel"} currency={false} />
          </div>
        </div>
      </div>

      {role === "admin" && (
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", borderBottom: "1px solid var(--divider)" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Agent leaderboard</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Sorted by total paid</div>
            </div>
          </div>
          <table className="tbl">
            <thead><tr>
              <th style={{ width: 40 }}>#</th>
              <th>Agent</th>
              <th>Phone</th>
              <th className="tbl-num">Total paid</th>
              <th className="tbl-num">Txns</th>
              <th className="tbl-num">Avg amount</th>
              <th style={{ width: 180 }}>Performance</th>
            </tr></thead>
            <tbody>
              {agentPerf.map((p, i) => {
                const max = agentPerf[0].total;
                return (
                  <tr key={p.agent.id} onClick={() => onOpenAgent(p.agent.id)}>
                    <td style={{ color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
                      {i === 0 ? <span style={{ color: "var(--brand)" }}>★</span> : (i+1).toString().padStart(2,"0")}
                    </td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div className="avatar" style={{ background: `hsl(${(i*53)%360},60%,55%)` }}>{p.agent.name.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
                        <span style={{ fontSize: 13, fontWeight: 500 }}>{p.agent.name}</span>
                      </div>
                    </td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>{fmtPhone(p.agent.phone)}</td>
                    <td className="tbl-num mono" style={{ fontWeight: 500 }}>{fmtAmount(p.total)}</td>
                    <td className="tbl-num mono">{p.count}</td>
                    <td className="tbl-num mono" style={{ color: "var(--text-muted)" }}>{fmtAmount(p.count ? p.total / p.count : 0)}</td>
                    <td>
                      <MiniBar value={p.total} max={max} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ─── Settings ────────────────────────────────────────────────────────────────
const SettingsPage = ({ currentUser, onUpdate, theme, onToggleTheme, toast }) => {
  const [tab, setTab] = React.useState("profile");
  const [name, setName] = React.useState(currentUser.name);
  const [saving, setSaving] = React.useState(false);

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      onUpdate({ name });
      toast("success", "Profile updated");
      setSaving(false);
    }, 500);
  };

  return (
    <div className="page" style={{ maxWidth: 880 }}>
      <div className="page-head">
        <div>
          <h1 className="page-title">Settings</h1>
          <div className="page-sub">Manage your account and preferences</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 24 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {[
            ["profile", "Profile", "user"],
            ["appearance", "Appearance", "sun"],
            ["security", "Security", "shield"],
            ["notifications", "Notifications", "bell"],
          ].map(([k,l,ic]) => (
            <div key={k} className={"nav-item" + (tab === k ? " active" : "")} onClick={() => setTab(k)}>
              <Icon name={ic} className="ni-icon" />
              <span>{l}</span>
            </div>
          ))}
        </div>

        <div>
          {tab === "profile" && (
            <div className="card card-pad">
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Profile</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 22 }}>Your basic information</div>

              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 22, paddingBottom: 22, borderBottom: "1px solid var(--divider)" }}>
                <div className="avatar avatar-xl">{name.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{name}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{currentUser.role === "admin" ? "Administrator" : "Agent"} · joined {fmtDateShort(currentUser.createdAt)}</div>
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <div>
                  <label className="label">Full name</label>
                  <input className="input" value={name} onChange={e => setName(e.target.value)} />
                </div>
                <div>
                  <label className="label">Phone (read-only)</label>
                  <input className="input mono" value={fmtPhone(currentUser.phone)} readOnly style={{ background: "var(--surface-3)", color: "var(--text-muted)" }} />
                </div>
                <div>
                  <label className="label">Role</label>
                  <input className="input" value={currentUser.role} readOnly style={{ background: "var(--surface-3)", color: "var(--text-muted)", textTransform: "capitalize" }} />
                </div>
                <div>
                  <label className="label">User ID</label>
                  <input className="input mono" value={currentUser.id} readOnly style={{ background: "var(--surface-3)", color: "var(--text-muted)", fontSize: 12 }} />
                </div>
              </div>

              <div style={{ marginTop: 22, display: "flex", justifyContent: "flex-end", gap: 8 }}>
                <button className="btn" onClick={() => setName(currentUser.name)}>Reset</button>
                <button className="btn btn-primary" disabled={saving || name === currentUser.name} onClick={save} style={{ opacity: (saving || name === currentUser.name) ? 0.6 : 1 }}>
                  {saving ? "Saving…" : "Save changes"}
                </button>
              </div>
            </div>
          )}

          {tab === "appearance" && (
            <div className="card card-pad">
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Appearance</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 22 }}>Theme and density</div>

              <div className="label">Theme</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  { k: "dark", label: "Dark", colors: ["#0A0B10","#161924","#E2136E"] },
                  { k: "light", label: "Light", colors: ["#F6F7FA","#FFFFFF","#E2136E"] },
                ].map(t => (
                  <div key={t.k} onClick={() => theme !== t.k && onToggleTheme()}
                    style={{ padding: 14, border: "2px solid", borderColor: theme === t.k ? "var(--brand)" : "var(--border)", borderRadius: "var(--r-md)", cursor: "pointer", background: t.colors[0], transition: "all 0.12s" }}>
                    <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                      {t.colors.map((c,i) => <div key={i} style={{ width: 20, height: 20, borderRadius: 4, background: c, border: "1px solid rgba(255,255,255,0.05)" }} />)}
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: t.k === "dark" ? "white" : "#0B0D14", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      {t.label}
                      {theme === t.k && <Icon name="check-circle" size={15} style={{ color: "var(--brand-2)" }} />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "security" && (
            <div className="card card-pad">
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Security</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 22 }}>OTP-based — no password required</div>

              <div style={{ padding: 16, background: "var(--surface-2)", borderRadius: "var(--r-md)", border: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 38, height: 38, borderRadius: "50%", background: "var(--success-soft)", color: "var(--success)", display: "grid", placeItems: "center" }}><Icon name="lock" size={16} /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>OTP authentication active</div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)" }}>Sign-ins require a 6-digit code sent to your registered SIM</div>
                </div>
                <span className="pill pill-success"><span className="pill-dot" />On</span>
              </div>

              <div style={{ marginTop: 16, padding: 16, background: "var(--surface-2)", borderRadius: "var(--r-md)", border: "1px solid var(--border)" }}>
                <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>Active sessions</div>
                <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 10 }}>1 device · this browser</div>
                <button className="btn btn-sm">Sign out all other devices</button>
              </div>
            </div>
          )}

          {tab === "notifications" && (
            <div className="card card-pad">
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Notifications</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 22 }}>When should we ping you?</div>

              {[
                ["new-tx", "New transaction received", true],
                ["paid", "Mark-as-paid confirmations", true],
                ["agent", "Agent status changes", false],
                ["report", "Weekly summary email", true],
              ].map(([k,l,d]) => <NotifToggle key={k} label={l} defaultOn={d} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const NotifToggle = ({ label, defaultOn }) => {
  const [on, setOn] = React.useState(defaultOn);
  return (
    <div onClick={() => setOn(!on)} style={{ padding: "12px 14px", border: "1px solid var(--border)", borderRadius: "var(--r-sm)", marginBottom: 8, display: "flex", alignItems: "center", gap: 12, cursor: "pointer" }}>
      <div style={{ flex: 1, fontSize: 13 }}>{label}</div>
      <div style={{ width: 32, height: 18, borderRadius: 9, background: on ? "var(--brand)" : "var(--surface-3)", position: "relative", transition: "background 0.15s" }}>
        <div style={{ position: "absolute", top: 2, left: on ? 16 : 2, width: 14, height: 14, borderRadius: "50%", background: "white", transition: "left 0.15s", boxShadow: "0 1px 2px rgba(0,0,0,0.3)" }} />
      </div>
    </div>
  );
};

Object.assign(window, { ReportsPage, SettingsPage });
