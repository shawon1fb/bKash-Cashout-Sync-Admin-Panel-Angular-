// ─── Mock data for bKash Cashout Sync ─────────────────────────────────────

const FIRST = ["Rakib","Sumaiya","Nasir","Tasnim","Mohammad","Fatema","Arif","Mehedi","Rumana","Sabbir","Anika","Imran","Faisal","Nusrat","Kamrul","Shahriar","Tahmid","Jannatul","Mosharraf","Habiba","Ridwan","Tania","Mahbub","Sadia","Jubair","Farhana"];
const LAST = ["Hasan","Akter","Uddin","Rahman","Ali","Begum","Hossain","Khatun","Ahmed","Tabassum","Mahmud","Jahan","Islam","Karim","Chowdhury","Siddique","Rashid","Sultana","Khan","Mollah","Bhuiyan","Sarker"];

const rand = (n) => Math.floor(Math.random()*n);
const pick = (a) => a[rand(a.length)];

function randomPhone(seed) {
  const ops = ["13","14","15","16","17","18","19"];
  // deterministic-ish from seed
  const s = String(seed||"").split("").reduce((a,c)=>a + c.charCodeAt(0), 0) || rand(99999);
  const o = ops[s % ops.length];
  let n = "01" + o;
  for (let i = 0; i < 8; i++) n += ((s * (i+3)) % 10);
  return n.slice(0,11);
}

function randomTrxId() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 10; i++) s += chars[rand(chars.length)];
  return s;
}

function fullName(seed) {
  const s = seed||0;
  return FIRST[s % FIRST.length] + " " + LAST[(s*7) % LAST.length];
}

// AGENTS
const AGENTS = [];
const NUM_AGENTS = 14;
for (let i = 0; i < NUM_AGENTS; i++) {
  const name = fullName(i + 3);
  const created = new Date(Date.now() - (NUM_AGENTS-i)*4*86400000 - rand(86400000));
  AGENTS.push({
    id: "agt-" + (1000+i),
    name,
    phone: "01" + pick(["7","8","9","6","5","3"]) + String(10000000 + (i*8413+1234567)%89999999),
    role: "agent",
    isActive: i !== 3 && i !== 9, // a couple inactive
    createdAt: created.toISOString(),
    updatedAt: created.toISOString(),
    // mock perf
    totalPaid: 0,
    totalCount: 0,
  });
}

// Add admin user (you)
const ADMIN = {
  id: "adm-001",
  name: "Ayesha Karim",
  phone: "01711223344",
  role: "admin",
  isActive: true,
  createdAt: new Date(Date.now() - 90*86400000).toISOString(),
  updatedAt: new Date().toISOString(),
};

// TRANSACTIONS
const TRANSACTIONS = [];
const STATUSES = ["paid","paid","paid","paid","received","received","paid"];
const NUM_TX = 240;
const now = Date.now();

for (let i = 0; i < NUM_TX; i++) {
  const agent = AGENTS[rand(AGENTS.length)];
  // bias time so recent is denser
  const daysBack = Math.floor(Math.pow(rand(900)/30, 0.85));
  const t = new Date(now - daysBack*86400000 - rand(86400000));
  const amount = (Math.floor((100 + Math.pow(rand(40), 1.6)*40 + rand(2000)) / 50) * 50).toFixed(2);
  const fee = (parseFloat(amount) * 0.0185).toFixed(2);
  const balance = (1000 + rand(45000)).toFixed(2);
  const status = STATUSES[rand(STATUSES.length)];
  const sender = randomPhone(i+"s");
  const trx = randomTrxId();
  const dateStr = `${String(t.getDate()).padStart(2,"0")}/${String(t.getMonth()+1).padStart(2,"0")}/${String(t.getFullYear()).slice(2)}`;
  const timeStr = `${((t.getHours()%12)||12)}:${String(t.getMinutes()).padStart(2,"0")} ${t.getHours()>=12?"PM":"AM"}`;

  TRANSACTIONS.push({
    id: "tx-" + (10000+i),
    transactionId: trx,
    amount,
    fee,
    balance,
    transactionTime: t.toISOString(),
    status,
    agentId: agent.id,
    agentName: agent.name,
    agentPhone: agent.phone,
    senderPhone: sender,
    receiverPhone: agent.phone,
    rawMessage: `Cash Out Tk ${parseFloat(amount).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})} from ${sender} successful. TrxID ${trx}. Fee Tk ${fee}. Balance Tk ${parseFloat(balance).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}. ${dateStr} ${timeStr}`,
    createdAt: t.toISOString(),
  });
}

TRANSACTIONS.sort((a,b) => new Date(b.transactionTime) - new Date(a.transactionTime));

// Compute agent performance
AGENTS.forEach(a => {
  const my = TRANSACTIONS.filter(t => t.agentId === a.id && t.status === "paid");
  a.totalPaid = my.reduce((s,t) => s + parseFloat(t.amount), 0);
  a.totalCount = my.length;
});

// Utilities ─────────────────────────────────────────────────────────────────

function fmtAmount(n, withCurrency = true) {
  const num = typeof n === "string" ? parseFloat(n) : n;
  const s = num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return withCurrency ? `৳ ${s}` : s;
}
function fmtAmountShort(n) {
  const num = typeof n === "string" ? parseFloat(n) : n;
  if (num >= 10000000) return `৳ ${(num/10000000).toFixed(2)}Cr`;
  if (num >= 100000)   return `৳ ${(num/100000).toFixed(2)}L`;
  if (num >= 1000)     return `৳ ${(num/1000).toFixed(1)}K`;
  return `৳ ${num.toFixed(0)}`;
}
function fmtPhone(p) {
  if (!p) return "—";
  return p.slice(0,3) + "-" + p.slice(3,7) + "-" + p.slice(7);
}
function fmtDate(iso, withTime = true) {
  const d = new Date(iso);
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const day = `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  if (!withTime) return day;
  const h12 = ((d.getHours()%12)||12);
  const ampm = d.getHours()>=12?"PM":"AM";
  return `${day}, ${h12}:${String(d.getMinutes()).padStart(2,"0")} ${ampm}`;
}
function fmtDateShort(iso) {
  const d = new Date(iso);
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${d.getDate()} ${months[d.getMonth()]}`;
}
function fmtRelative(iso) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  if (diff < 86400*7) return `${Math.floor(diff/86400)}d ago`;
  return fmtDateShort(iso);
}

// Group transactions by day
function dailySeries(transactions, days = 7) {
  const buckets = [];
  for (let i = days-1; i >= 0; i--) {
    const day = new Date();
    day.setHours(0,0,0,0);
    day.setDate(day.getDate() - i);
    const next = new Date(day); next.setDate(next.getDate()+1);
    const items = transactions.filter(t => {
      const tt = new Date(t.transactionTime);
      return tt >= day && tt < next;
    });
    const paid = items.filter(t => t.status === "paid");
    buckets.push({
      date: day,
      label: day.toLocaleDateString("en", { weekday: "short" }),
      shortLabel: `${day.getDate()}/${day.getMonth()+1}`,
      count: items.length,
      paidAmount: paid.reduce((s,t)=> s + parseFloat(t.amount), 0),
      paidCount: paid.length,
      receivedCount: items.length - paid.length,
    });
  }
  return buckets;
}

function monthlySeries(transactions, months = 6) {
  const buckets = [];
  for (let i = months-1; i >= 0; i--) {
    const ref = new Date();
    ref.setDate(1); ref.setHours(0,0,0,0);
    ref.setMonth(ref.getMonth() - i);
    const next = new Date(ref); next.setMonth(next.getMonth()+1);
    const items = transactions.filter(t => {
      const tt = new Date(t.transactionTime);
      return tt >= ref && tt < next;
    });
    const paid = items.filter(t => t.status === "paid");
    const m = ref.toLocaleDateString("en", { month: "short" });
    buckets.push({
      date: ref,
      label: m,
      count: items.length,
      paidAmount: paid.reduce((s,t)=> s + parseFloat(t.amount), 0),
      paidCount: paid.length,
    });
  }
  return buckets;
}

// Expose
Object.assign(window, {
  ADMIN, AGENTS, TRANSACTIONS,
  fmtAmount, fmtAmountShort, fmtPhone, fmtDate, fmtDateShort, fmtRelative,
  dailySeries, monthlySeries,
  randomPhone, randomTrxId, fullName, pick, rand
});
