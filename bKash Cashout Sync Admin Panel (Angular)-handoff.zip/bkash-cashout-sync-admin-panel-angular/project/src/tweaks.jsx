// ─── Tweaks for bKash admin ───────────────────────────────────────────────────
const APP_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "pink",
  "density": "comfortable",
  "radius": 14,
  "showLiveStream": true,
  "showHeatmap": true
}/*EDITMODE-END*/;

const ACCENT_PRESETS = {
  pink:   { brand: "#E2136E", brand2: "#FF3D87", soft: "rgba(226,19,110,0.14)", ring: "rgba(226,19,110,0.32)" },
  blue:   { brand: "#2563EB", brand2: "#3B82F6", soft: "rgba(37,99,235,0.14)",  ring: "rgba(37,99,235,0.32)" },
  violet: { brand: "#7C3AED", brand2: "#A78BFA", soft: "rgba(124,58,237,0.14)", ring: "rgba(124,58,237,0.32)" },
  green:  { brand: "#10B981", brand2: "#34D399", soft: "rgba(16,185,129,0.14)", ring: "rgba(16,185,129,0.32)" },
  orange: { brand: "#F97316", brand2: "#FB923C", soft: "rgba(249,115,22,0.14)", ring: "rgba(249,115,22,0.32)" },
};

function AppTweaks() {
  const [t, setTweak] = useTweaks(APP_TWEAK_DEFAULTS);

  React.useEffect(() => {
    const p = ACCENT_PRESETS[t.accent] || ACCENT_PRESETS.pink;
    const r = document.documentElement.style;
    r.setProperty("--brand", p.brand);
    r.setProperty("--brand-2", p.brand2);
    r.setProperty("--brand-soft", p.soft);
    r.setProperty("--brand-ring", p.ring);
    r.setProperty("--r-lg", t.radius + "px");
    r.setProperty("--r-md", Math.max(6, t.radius - 4) + "px");
    document.body.style.fontSize = t.density === "compact" ? "13px" : "14px";
    document.documentElement.style.setProperty("--gutter", t.density === "compact" ? "12px" : "20px");
  }, [t]);

  const accentPaletteOptions = Object.entries(ACCENT_PRESETS).map(([, p]) => [p.brand, p.brand2]);
  const currentPalette = [ACCENT_PRESETS[t.accent].brand, ACCENT_PRESETS[t.accent].brand2];

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Accent" />
      <TweakColor
        label="Brand"
        value={currentPalette}
        options={accentPaletteOptions}
        onChange={(v) => {
          const key = Object.entries(ACCENT_PRESETS).find(([, p]) => p.brand === v[0])?.[0] || "pink";
          setTweak("accent", key);
        }}
      />

      <TweakSection label="Layout" />
      <TweakRadio
        label="Density"
        value={t.density}
        options={["comfortable", "compact"]}
        onChange={(v) => setTweak("density", v)}
      />
      <TweakSlider
        label="Card radius"
        value={t.radius}
        min={4} max={22} step={1} unit="px"
        onChange={(v) => setTweak("radius", v)}
      />
    </TweaksPanel>
  );
}

// Mount tweaks alongside the app
const tweaksRoot = document.createElement("div");
tweaksRoot.id = "tweaks-root";
document.body.appendChild(tweaksRoot);
ReactDOM.createRoot(tweaksRoot).render(<AppTweaks />);
