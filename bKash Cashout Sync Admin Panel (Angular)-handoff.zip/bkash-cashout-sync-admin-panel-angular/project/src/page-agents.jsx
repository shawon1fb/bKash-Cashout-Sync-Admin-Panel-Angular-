// ─── Agents list ──────────────────────────────────────────────────────────────
const AgentList = ({ onOpenAgent, onCreate, toast }) => {
  const [search, setSearch] = React.useState("");
  const [filter, setFilter] = React.useState("all");
  const [sortBy, setSortBy] = React.useState("paid"); // "name" | "paid" | "count" | "created"
  const [confirm, setConfirm] = React.useState(null); // agent to deactivate
  const [showCreate, setShowCreate] = React.useState(false);
  const [agents, setAgents] = React.useState(window.AGENTS);

  const filtered = agents.filter(a => {
    if (search && !a.name.toLowerCase().includes(search.toLowerCase()) && !a.phone.includes(search)) return false;
    if (filter === "active" && !a.isActive) return false;
    if (filter === "inactive" && a.isActive) return false;
    return true;
  }).sort((a,b) => {
    if (sortBy === "name") return a.name.localeCompare(b.name);
    if (sortBy === "paid") return b.totalPaid - a.totalPaid;
    if (sortBy === "count") return b.totalCount - a.totalCount;
    if (sortBy === "created") return new Date(b.createdAt) - new Date(a.createdAt);
    return 0;
  });

  const deactivate = (id) => {
    const updated = agents.map(a => a.id === id ? { ...a, isActive: !a.isActive } : a);
    setAgents(updated);
    window.AGENTS = updated;
    toast(confirm.isActive ? "success" : "info", `${confirm.name} ${confirm.isActive ? "deactivated" : "reactivated"}`);
    setConfirm(null);
  };

  const handleCreate = (data) => {
    const newAgent = {
      id: "agt-" + (1000 + agents.length),
      name: data.name,
      phone: data.phone,
      role: "agent",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      totalPaid: 0,
      totalCount: 0,
    };
    const updated = [newAgent, ...agents];
    setAgents(updated);
    window.AGENTS = updated;
    toast("success", `Agent ${data.name} created`);
    setShowCreate(false);
  };

  const activeCount = agents.filter(a => a.isActive).length;
  const totalPaidAll = agents.reduce((s,a) => s+a.totalPaid, 0);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">Agents</h1>
          <div className="page-sub">
            {agents.length} total <span className="dot-sep" />
            <span style={{ color: "var(--success)" }}>{activeCount} active</span>
            <span className="dot-sep" />
            <span className="mono">{fmtAmountShort(totalPaidAll)} lifetime paid</span>
          </div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
          <Icon name="plus" size={13} /> Add agent
        </button>
      </div>

      <div className="card" style={{ padding: 14, marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ position: "relative", flex: "0 0 320px" }}>
            <Icon name="search" size={14} style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
            <input className="input" style={{ paddingLeft: 32 }} placeholder="Search by name or phone…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="seg">
            <button className={filter === "all" ? "on" : ""} onClick={() => setFilter("all")}>All</button>
            <button className={filter === "active" ? "on" : ""} onClick={() => setFilter("active")}>Active</button>
            <button className={filter === "inactive" ? "on" : ""} onClick={() => setFilter("inactive")}>Inactive</button>
          </div>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 12, color: "var(--text-muted)" }}>Sort:</span>
          <select className="input" style={{ width: "auto", padding: "6px 26px 6px 10px", fontSize: 12 }} value={sortBy} onChange={e => setSortBy(e.target.value)}>
            <option value="paid">Total paid</option>
            <option value="count">Transaction count</option>
            <option value="name">Name</option>
            <option value="created">Date added</option>
          </select>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table className="tbl">
          <thead>
            <tr>
              <th>Agent</th>
              <th>Phone</th>
              <th className="tbl-num">Total paid</th>
              <th className="tbl-num">Txns</th>
              <th>Status</th>
              <th>Joined</th>
              <th style={{ width: 100 }}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={7} style={{ padding: 60, textAlign: "center", color: "var(--text-muted)" }}>
                <Icon name="users" size={24} style={{ opacity: 0.4, marginBottom: 8 }} />
                <div style={{ fontSize: 14 }}>No agents match your filters</div>
              </td></tr>
            )}
            {filtered.map((a, i) => {
              const max = filtered[0].totalPaid;
              return (
                <tr key={a.id} onClick={() => onOpenAgent(a.id)}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div className="avatar" style={{ background: `linear-gradient(135deg, hsl(${(i*53)%360}, 60%, 55%), hsl(${(i*53+40)%360}, 60%, 45%))` }}>
                        {a.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
                      </div>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{a.name}</div>
                        <div style={{ fontSize: 11, color: "var(--text-dim)", fontFamily: "var(--font-mono)" }}>{a.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="mono" style={{ fontSize: 12 }}>{fmtPhone(a.phone)}</td>
                  <td className="tbl-num">
                    <div className="mono" style={{ fontWeight: 500 }}>{fmtAmount(a.totalPaid)}</div>
                    <div style={{ width: 80, marginLeft: "auto", marginTop: 4 }}>
                      <MiniBar value={a.totalPaid} max={max} />
                    </div>
                  </td>
                  <td className="tbl-num mono">{a.totalCount}</td>
                  <td><StatusBadge status={a.isActive ? "active" : "inactive"} /></td>
                  <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{fmtDateShort(a.createdAt)}</td>
                  <td style={{ textAlign: "right" }}>
                    <div style={{ display: "inline-flex", gap: 4 }}>
                      <button className="btn btn-sm btn-ghost btn-icon" onClick={(e) => { e.stopPropagation(); onOpenAgent(a.id); }} title="View"><Icon name="eye" size={13} /></button>
                      <button className="btn btn-sm btn-ghost btn-icon" onClick={(e) => { e.stopPropagation(); setConfirm(a); }} title={a.isActive ? "Deactivate" : "Reactivate"}>
                        <Icon name={a.isActive ? "lock" : "refresh"} size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showCreate && <CreateAgentDialog onClose={() => setShowCreate(false)} onCreate={handleCreate} existingPhones={agents.map(a=>a.phone)} />}

      {confirm && (
        <ConfirmDialog
          title={confirm.isActive ? "Deactivate agent?" : "Reactivate agent?"}
          message={confirm.isActive
            ? <>This will prevent <b>{confirm.name}</b> from being matched on incoming transactions. Existing records keep their assignment.</>
            : <>This will reactivate <b>{confirm.name}</b> and resume matching them on new transactions.</>}
          confirmLabel={confirm.isActive ? "Deactivate" : "Reactivate"}
          isDanger={confirm.isActive}
          onConfirm={() => deactivate(confirm.id)}
          onClose={() => setConfirm(null)}
        />
      )}
    </div>
  );
};

// ─── Create Agent Dialog ──────────────────────────────────────────────────────
const CreateAgentDialog = ({ onClose, onCreate, existingPhones }) => {
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [err, setErr] = React.useState({});
  const [busy, setBusy] = React.useState(false);

  const submit = () => {
    const e = {};
    if (name.length < 2 || name.length > 100) e.name = "Name must be 2–100 characters";
    if (!/^01[3-9]\d{8}$/.test(phone)) e.phone = "Invalid Bangladeshi number";
    if (existingPhones.includes(phone)) e.phone = "Phone already registered";
    setErr(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    setTimeout(() => onCreate({ name, phone }), 500);
  };

  return (
    <div className="dialog-backdrop" onClick={onClose}>
      <div className="dialog" onClick={e => e.stopPropagation()}>
        <div style={{ padding: "18px 22px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid var(--divider)" }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>Add new agent</div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>They'll appear in the matching pool immediately.</div>
          </div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>

        <div style={{ padding: 22 }}>
          <div style={{ marginBottom: 14 }}>
            <label className="label">Full name</label>
            <input className="input" placeholder="e.g. Rakib Hasan" value={name} onChange={e => { setName(e.target.value); setErr({...err, name: undefined}); }} autoFocus />
            {err.name && <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 5 }}>{err.name}</div>}
          </div>
          <div>
            <label className="label">Agent phone number</label>
            <div style={{ position: "relative" }}>
              <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 13, color: "var(--text-muted)", pointerEvents: "none" }}>+880</span>
              <input className="input" style={{ paddingLeft: 50, fontFamily: "var(--font-mono)" }} placeholder="01XXXXXXXXX" value={phone} onChange={e => { setPhone(e.target.value.replace(/\D/g,"").slice(0,11)); setErr({...err, phone: undefined}); }} maxLength={11} />
            </div>
            {err.phone && <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 5 }}>{err.phone}</div>}
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 6 }}>Must be the bKash-registered agent SIM</div>
          </div>
        </div>

        <div style={{ padding: "14px 22px", borderTop: "1px solid var(--divider)", display: "flex", justifyContent: "flex-end", gap: 8 }}>
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={submit} disabled={busy} style={{ opacity: busy ? 0.6 : 1 }}>
            {busy ? "Creating…" : <><Icon name="check" size={13} /> Create agent</>}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Confirm Dialog ───────────────────────────────────────────────────────────
const ConfirmDialog = ({ title, message, confirmLabel = "Confirm", isDanger, onConfirm, onClose }) => (
  <div className="dialog-backdrop" onClick={onClose}>
    <div className="dialog" onClick={e => e.stopPropagation()}>
      <div style={{ padding: "20px 22px 12px" }}>
        <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
          <div style={{ width: 38, height: 38, borderRadius: "50%", background: isDanger ? "var(--danger-soft)" : "var(--info-soft)", display: "grid", placeItems: "center", color: isDanger ? "var(--danger)" : "var(--info)", flexShrink: 0 }}>
            <Icon name={isDanger ? "alert" : "info"} size={18} />
          </div>
          <div style={{ flex: 1, paddingTop: 4 }}>
            <div style={{ fontSize: 15, fontWeight: 600 }}>{title}</div>
            <div style={{ fontSize: 13, color: "var(--text-2)", marginTop: 6, lineHeight: 1.55 }}>{message}</div>
          </div>
        </div>
      </div>
      <div style={{ padding: "14px 22px", borderTop: "1px solid var(--divider)", display: "flex", justifyContent: "flex-end", gap: 8 }}>
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className={"btn " + (isDanger ? "btn-danger" : "btn-primary")} onClick={onConfirm}>{confirmLabel}</button>
      </div>
    </div>
  </div>
);

// ─── Agent Detail ─────────────────────────────────────────────────────────────
const AgentDetail = ({ agentId, onBack, onOpenTransaction, toast }) => {
  const [period, setPeriod] = React.useState("monthly");
  const [editing, setEditing] = React.useState(false);
  const [confirm, setConfirm] = React.useState(false);
  const [agents, setAgents] = React.useState(window.AGENTS);
  const a = agents.find(x => x.id === agentId);
  const [name, setName] = React.useState(a?.name || "");

  if (!a) return <div className="page">Agent not found <button className="btn btn-sm" onClick={onBack}>Back</button></div>;

  const tx = window.TRANSACTIONS.filter(t => t.agentId === a.id);
  const paid = tx.filter(t => t.status === "paid");
  const received = tx.filter(t => t.status === "received");
  const daily = dailySeries(tx, 14);
  const recent = tx.slice(0, 15);

  const updateAgent = (changes) => {
    const updated = agents.map(x => x.id === a.id ? { ...x, ...changes, updatedAt: new Date().toISOString() } : x);
    setAgents(updated);
    window.AGENTS = updated;
  };

  return (
    <div className="page">
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16, fontSize: 13, color: "var(--text-muted)" }}>
        <button onClick={onBack} className="btn btn-ghost btn-sm"><Icon name="chevron-left" size={14} /> Agents</button>
        <span style={{ color: "var(--text-dim)" }}>/</span>
        <span style={{ color: "var(--text-2)" }}>{a.name}</span>
      </div>

      <div className="card" style={{ marginBottom: 14, padding: 24, display: "flex", alignItems: "center", gap: 20 }}>
        <div className="avatar avatar-xl" style={{ background: "linear-gradient(135deg, var(--brand), var(--brand-2))" }}>
          {a.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
        </div>
        <div style={{ flex: 1 }}>
          {editing ? (
            <input className="input" style={{ fontSize: 20, fontWeight: 600, padding: "6px 10px", maxWidth: 360 }} value={name} onChange={e => setName(e.target.value)} autoFocus />
          ) : (
            <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>{a.name}</div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 6, fontSize: 13, color: "var(--text-muted)" }}>
            <span style={{ display: "flex", alignItems: "center", gap: 6 }}><Icon name="phone" size={13} /> <span className="mono">{fmtPhone(a.phone)}</span></span>
            <span className="dot-sep" />
            <span>Joined {fmtDateShort(a.createdAt)}</span>
            <span className="dot-sep" />
            <StatusBadge status={a.isActive ? "active" : "inactive"} size="sm" />
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {editing ? (
            <>
              <button className="btn" onClick={() => { setName(a.name); setEditing(false); }}>Cancel</button>
              <button className="btn btn-primary" onClick={() => { updateAgent({ name }); setEditing(false); toast("success", "Agent updated"); }}><Icon name="check" size={13} /> Save</button>
            </>
          ) : (
            <>
              <button className="btn" onClick={() => setEditing(true)}><Icon name="edit" size={13} /> Edit</button>
              <button className={"btn " + (a.isActive ? "btn-danger" : "")} onClick={() => setConfirm(true)}>
                <Icon name={a.isActive ? "lock" : "refresh"} size={13} /> {a.isActive ? "Deactivate" : "Reactivate"}
              </button>
            </>
          )}
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>Period:</span>
        <div className="seg">
          {[["daily","Daily"],["weekly","Weekly"],["monthly","Monthly"],["custom","Custom"]].map(([k,l]) =>
            <button key={k} className={period === k ? "on" : ""} onClick={() => setPeriod(k)}>{l}</button>
          )}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
        <StatCard label="Lifetime paid" value={fmtAmountShort(a.totalPaid).replace("৳ ","")} currency icon="wallet" />
        <StatCard label="Transactions" value={tx.length} icon="transactions" trend={`${paid.length} paid`} trendDir="up" />
        <StatCard label="Pending payout" value={received.length} icon="clock" trend={fmtAmountShort(received.reduce((s,t)=>s+parseFloat(t.amount),0))} />
        <StatCard label="Avg transaction" value={fmtAmountShort(tx.length ? a.totalPaid / paid.length : 0).replace("৳ ","")} currency icon="trending-up" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.65fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Earnings — last 14 days</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Daily paid amount</div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <LineAreaChart data={daily} height={220} valueKey="paidAmount" labelKey="shortLabel" />
          </div>
        </div>

        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Distribution</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>By transaction status</div>
          </div>
          <div style={{ padding: 20, display: "grid", placeItems: "center" }}>
            <DonutChart
              segments={[
                { label: "Paid", value: paid.length, color: "var(--success)" },
                { label: "Received", value: received.length, color: "var(--warning)" },
              ]}
              centerLabel="Total"
              centerValue={tx.length}
              size={160}
            />
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", borderBottom: "1px solid var(--divider)" }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Recent transactions</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{tx.length} total</div>
          </div>
        </div>
        <table className="tbl">
          <thead><tr>
            <th>TrxID</th>
            <th>Sender</th>
            <th className="tbl-num">Amount</th>
            <th>Status</th>
            <th>Time</th>
          </tr></thead>
          <tbody>
            {recent.map(t => (
              <tr key={t.id} onClick={() => onOpenTransaction(t)}>
                <td className="mono" style={{ fontSize: 12 }}>{t.transactionId}</td>
                <td className="mono" style={{ fontSize: 12 }}>{fmtPhone(t.senderPhone)}</td>
                <td className="tbl-num mono">{fmtAmount(t.amount)}</td>
                <td><StatusBadge status={t.status} /></td>
                <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{fmtRelative(t.transactionTime)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {confirm && (
        <ConfirmDialog
          title={a.isActive ? "Deactivate this agent?" : "Reactivate this agent?"}
          message={<>This {a.isActive ? "removes" : "restores"} <b>{a.name}</b> from the active matching pool.</>}
          confirmLabel={a.isActive ? "Deactivate" : "Reactivate"}
          isDanger={a.isActive}
          onConfirm={() => { updateAgent({ isActive: !a.isActive }); setConfirm(false); toast(a.isActive ? "info" : "success", `Agent ${a.isActive ? "deactivated" : "reactivated"}`); }}
          onClose={() => setConfirm(false)}
        />
      )}
    </div>
  );
};

Object.assign(window, { AgentList, AgentDetail, CreateAgentDialog, ConfirmDialog });
