// ─── Transaction list (admin + agent variants) ────────────────────────────────
const TransactionList = ({ role, currentUser, onOpenTransaction, onNavigate }) => {
  const allTx = role === "admin" ? window.TRANSACTIONS : window.TRANSACTIONS.filter(t => t.agentId === currentUser.id);

  const [search, setSearch] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [agentFilter, setAgentFilter] = React.useState("all");
  const [dateRange, setDateRange] = React.useState("30d");
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(25);
  const [sortDesc, setSortDesc] = React.useState(true);

  React.useEffect(() => setPage(1), [search, status, agentFilter, dateRange]);

  const filtered = React.useMemo(() => {
    const now = Date.now();
    const ranges = { "7d": 7, "30d": 30, "90d": 90, "all": 99999 };
    const days = ranges[dateRange];
    return allTx.filter(t => {
      if (search && !t.transactionId.toLowerCase().includes(search.toLowerCase()) && !t.senderPhone.includes(search)) return false;
      if (status !== "all" && t.status !== status) return false;
      if (agentFilter !== "all" && t.agentId !== agentFilter) return false;
      if (days < 99999 && (now - new Date(t.transactionTime).getTime()) > days * 86400000) return false;
      return true;
    }).sort((a,b) => {
      const da = new Date(a.transactionTime).getTime();
      const db = new Date(b.transactionTime).getTime();
      return sortDesc ? db - da : da - db;
    });
  }, [allTx, search, status, agentFilter, dateRange, sortDesc]);

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;
  const slice = filtered.slice((page - 1) * pageSize, page * pageSize);

  const selectedAmount = filtered.reduce((s,t) => s + parseFloat(t.amount), 0);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">{role === "admin" ? "Transactions" : "My transactions"}</h1>
          <div className="page-sub">
            {filtered.length.toLocaleString()} txns
            <span className="dot-sep" />
            <span className="mono">{fmtAmount(selectedAmount)}</span>
            <span className="dot-sep" />
            <span style={{ color: "var(--text-2)" }}>{filtered.filter(t=>t.status==="paid").length} paid</span>
            <span className="dot-sep" />
            <span style={{ color: "var(--warning)" }}>{filtered.filter(t=>t.status==="received").length} pending</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn"><Icon name="download" size={13} /> Export CSV</button>
          <button className="btn btn-primary" onClick={() => onNavigate("upload")}><Icon name="plus" size={13} /> Upload SMS</button>
        </div>
      </div>

      <div className="card" style={{ padding: 14, marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ position: "relative", flex: "0 0 300px" }}>
            <Icon name="search" size={14} style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
            <input className="input" style={{ paddingLeft: 32 }} placeholder="Search TrxID or sender phone…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>

          <div style={{ display: "flex", gap: 6 }}>
            {[["all","All"],["paid","Paid"],["received","Received"]].map(([k,l]) => (
              <button key={k} className={"chip" + (status === k ? " on" : "")} onClick={() => setStatus(k)}>
                {k !== "all" && <span style={{ width: 7, height: 7, borderRadius: "50%", background: k === "paid" ? "var(--success)" : "var(--warning)" }} />}
                {l}
              </button>
            ))}
          </div>

          {role === "admin" && (
            <select className="input" style={{ width: "auto", padding: "6px 28px 6px 10px", fontSize: 12 }} value={agentFilter} onChange={e => setAgentFilter(e.target.value)}>
              <option value="all">All agents</option>
              {window.AGENTS.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          )}

          <div className="seg">
            {[["7d","7d"],["30d","30d"],["90d","90d"],["all","All time"]].map(([k,l]) => (
              <button key={k} className={dateRange === k ? "on" : ""} onClick={() => setDateRange(k)}>{l}</button>
            ))}
          </div>

          <div style={{ flex: 1 }} />

          {(search || status !== "all" || agentFilter !== "all") && (
            <button className="btn btn-sm btn-ghost" onClick={() => { setSearch(""); setStatus("all"); setAgentFilter("all"); }}>
              <Icon name="x" size={12} /> Reset
            </button>
          )}
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table className="tbl">
            <thead>
              <tr>
                <th>TrxID</th>
                {role === "admin" && <th>Agent</th>}
                <th>Sender</th>
                <th className="tbl-num">Amount</th>
                <th className="tbl-num">Fee</th>
                <th>Status</th>
                <th onClick={() => setSortDesc(s => !s)} style={{ cursor: "pointer", userSelect: "none" }}>
                  Time
                  <Icon name={sortDesc ? "arrow-down" : "arrow-up"} size={10} style={{ marginLeft: 4, verticalAlign: "middle" }} />
                </th>
                <th style={{ width: 100 }}></th>
              </tr>
            </thead>
            <tbody>
              {slice.length === 0 && (
                <tr><td colSpan={role === "admin" ? 8 : 7} style={{ padding: 60, textAlign: "center" }}>
                  <div style={{ color: "var(--text-muted)" }}>
                    <Icon name="search" size={24} style={{ opacity: 0.4, marginBottom: 8 }} />
                    <div style={{ fontSize: 14 }}>No transactions match your filters</div>
                  </div>
                </td></tr>
              )}
              {slice.map(t => (
                <tr key={t.id} onClick={() => onOpenTransaction(t)}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span className="mono" style={{ fontSize: 12, fontWeight: 500 }}>{t.transactionId}</span>
                      <button className="btn-ghost btn btn-sm btn-icon" title="Copy" onClick={(e) => { e.stopPropagation(); navigator.clipboard?.writeText(t.transactionId); }}>
                        <Icon name="copy" size={11} />
                      </button>
                    </div>
                  </td>
                  {role === "admin" && (
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div className="avatar" style={{ width: 22, height: 22, fontSize: 9 }}>{t.agentName.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
                        <span style={{ fontSize: 13 }}>{t.agentName}</span>
                      </div>
                    </td>
                  )}
                  <td className="mono" style={{ fontSize: 12, color: "var(--text-2)" }}>{fmtPhone(t.senderPhone)}</td>
                  <td className="tbl-num mono" style={{ fontWeight: 500 }}>{fmtAmount(t.amount)}</td>
                  <td className="tbl-num mono" style={{ color: "var(--text-muted)", fontSize: 12 }}>{fmtAmount(t.fee, false)}</td>
                  <td><StatusBadge status={t.status} /></td>
                  <td>
                    <div style={{ fontSize: 12 }}>{fmtRelative(t.transactionTime)}</div>
                    <div style={{ fontSize: 10, color: "var(--text-dim)" }}>{fmtDateShort(t.transactionTime)}</div>
                  </td>
                  <td style={{ textAlign: "right" }}>
                    {t.status === "received" && (
                      <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); window._markPaid?.(t.id); }}>
                        Mark paid
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <Pagination page={page} totalPages={totalPages} pageSize={pageSize} totalItems={filtered.length}
          onPage={setPage} onPageSize={setPageSize} />
      </div>
    </div>
  );
};

const Pagination = ({ page, totalPages, pageSize, totalItems, onPage, onPageSize }) => {
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalItems);
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderTop: "1px solid var(--divider)", fontSize: 12, color: "var(--text-muted)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span>Rows per page:</span>
        <select value={pageSize} onChange={e => onPageSize(+e.target.value)} className="input" style={{ width: "auto", padding: "4px 22px 4px 8px", fontSize: 12 }}>
          {[10,25,50,100].map(n => <option key={n} value={n}>{n}</option>)}
        </select>
        <span>{totalItems === 0 ? "0 of 0" : `${from}–${to} of ${totalItems}`}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
        <button className="btn btn-sm btn-ghost btn-icon" onClick={() => onPage(Math.max(1, page-1))} disabled={page <= 1} style={{ opacity: page <= 1 ? 0.4 : 1 }}>
          <Icon name="chevron-left" size={13} />
        </button>
        <span style={{ padding: "0 8px", fontFamily: "var(--font-mono)" }}>{page} / {totalPages}</span>
        <button className="btn btn-sm btn-ghost btn-icon" onClick={() => onPage(Math.min(totalPages, page+1))} disabled={page >= totalPages} style={{ opacity: page >= totalPages ? 0.4 : 1 }}>
          <Icon name="chevron-right" size={13} />
        </button>
      </div>
    </div>
  );
};

// ─── Transaction Drawer ───────────────────────────────────────────────────────
const TransactionDrawer = ({ tx, onClose, onMarkPaid }) => {
  if (!tx) return null;
  const agent = window.AGENTS.find(a => a.id === tx.agentId);

  const stages = [
    { label: "Captured", time: tx.createdAt, done: true },
    { label: "Received in queue", time: tx.transactionTime, done: true },
    { label: "Paid out", time: tx.status === "paid" ? new Date(new Date(tx.transactionTime).getTime() + 2*60000).toISOString() : null, done: tx.status === "paid", current: tx.status === "received" },
  ];

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <aside className="drawer">
        <div style={{ padding: "16px 22px", borderBottom: "1px solid var(--divider)", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Transaction</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 3 }}>
              <span className="mono" style={{ fontSize: 16, fontWeight: 600 }}>{tx.transactionId}</span>
              <button className="btn btn-ghost btn-sm btn-icon" onClick={() => navigator.clipboard?.writeText(tx.transactionId)} title="Copy">
                <Icon name="copy" size={12} />
              </button>
            </div>
          </div>
          <StatusBadge status={tx.status} />
          <button className="btn btn-ghost btn-icon" onClick={onClose}>
            <Icon name="x" size={16} />
          </button>
        </div>

        <div style={{ overflow: "auto", flex: 1, padding: 22 }}>
          <div style={{ padding: 20, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-lg)", marginBottom: 18 }}>
            <div style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Amount</div>
            <div style={{ fontSize: 30, fontWeight: 600, fontVariantNumeric: "tabular-nums", letterSpacing: "-0.02em", marginTop: 4, fontFamily: "var(--font-display)" }}>
              <span style={{ color: "var(--text-muted)", fontWeight: 400, marginRight: 4 }}>৳</span>
              {fmtAmount(tx.amount, false)}
            </div>
            <div style={{ display: "flex", gap: 24, marginTop: 14, fontSize: 12 }}>
              <div>
                <div style={{ color: "var(--text-muted)", fontSize: 11 }}>Fee</div>
                <div className="mono" style={{ marginTop: 2 }}>{fmtAmount(tx.fee)}</div>
              </div>
              <div>
                <div style={{ color: "var(--text-muted)", fontSize: 11 }}>Balance after</div>
                <div className="mono" style={{ marginTop: 2 }}>{fmtAmount(tx.balance)}</div>
              </div>
              <div>
                <div style={{ color: "var(--text-muted)", fontSize: 11 }}>Net</div>
                <div className="mono" style={{ marginTop: 2, color: "var(--success)" }}>+{fmtAmount(parseFloat(tx.amount) - parseFloat(tx.fee))}</div>
              </div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 18 }}>
            <div>
              <div className="label">From</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div className="avatar" style={{ background: "var(--surface-3)", color: "var(--text-2)", fontSize: 11 }}>
                  <Icon name="phone" size={12} />
                </div>
                <div>
                  <div className="mono" style={{ fontSize: 13 }}>{fmtPhone(tx.senderPhone)}</div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)" }}>Sender</div>
                </div>
              </div>
            </div>
            <div>
              <div className="label">To (Agent)</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div className="avatar">{agent.name.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{agent.name}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{fmtPhone(agent.phone)}</div>
                </div>
              </div>
            </div>
          </div>

          <div style={{ marginBottom: 18 }}>
            <div className="label">Timeline</div>
            <div className="timeline" style={{ marginTop: 4 }}>
              {stages.map((s, i) => (
                <div key={i} className={"timeline-item" + (s.done ? " done" : "") + (s.current ? " current" : "")}>
                  <div className="timeline-label">{s.label}</div>
                  <div className="timeline-time">{s.time ? fmtDate(s.time) : "Pending"}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 18 }}>
            <div className="label">Raw SMS</div>
            <div style={{ padding: 14, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-md)", fontFamily: "var(--font-mono)", fontSize: 12, lineHeight: 1.6, color: "var(--text-2)" }}>
              {tx.rawMessage}
            </div>
          </div>

          <div>
            <div className="label">Metadata</div>
            <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "8px 16px", fontSize: 12 }}>
              <div style={{ color: "var(--text-muted)" }}>Internal ID</div>
              <div className="mono">{tx.id}</div>
              <div style={{ color: "var(--text-muted)" }}>Created</div>
              <div>{fmtDate(tx.createdAt)}</div>
              <div style={{ color: "var(--text-muted)" }}>Transaction time</div>
              <div>{fmtDate(tx.transactionTime)}</div>
            </div>
          </div>
        </div>

        <div style={{ padding: "14px 22px", borderTop: "1px solid var(--divider)", display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button className="btn" onClick={onClose}>Close</button>
          {tx.status === "received" && (
            <button className="btn btn-primary" onClick={() => { onMarkPaid(tx.id); onClose(); }}>
              <Icon name="check" size={13} /> Mark as paid
            </button>
          )}
        </div>
      </aside>
    </>
  );
};

// ─── Upload SMS ───────────────────────────────────────────────────────────────
const UploadPage = ({ onParsed, currentUser, role }) => {
  const SAMPLES = [
    "Cash Out Tk 2,500.00 from 01755112233 successful. TrxID K8M3P7N2Q4. Fee Tk 25.00. Balance Tk 12,450.00. 13/05/26 11:42 AM",
    "Cash Out Tk 800.00 from 01911334455 successful. TrxID R3T5V7Y9Z1. Fee Tk 8.00. Balance Tk 8,200.00. 13/05/26 09:15 AM",
    "Cash Out Tk 5,000.00 from 01612998877 successful. TrxID B4G6H8J2K5. Fee Tk 50.00. Balance Tk 22,800.00. 12/05/26 4:08 PM"
  ];

  const activeAgents = window.AGENTS.filter(a => a.isActive);
  const [text, setText] = React.useState("");
  const [parsed, setParsed] = React.useState(null);
  const [error, setError] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [agentId, setAgentId] = React.useState(role === "admin" ? activeAgents[0]?.id : currentUser.id);
  const [agentPickerOpen, setAgentPickerOpen] = React.useState(false);
  const [agentSearch, setAgentSearch] = React.useState("");
  const selectedAgent = role === "admin"
    ? window.AGENTS.find(a => a.id === agentId)
    : currentUser;

  function parse(raw) {
    const re = /Cash Out Tk\s+([\d,]+\.\d{2})\s+from\s+(01\d{9})\s+successful\.\s+TrxID\s+([A-Z0-9]+)\.\s+Fee Tk\s+([\d,]+\.\d{2})\.\s+Balance Tk\s+([\d,]+\.\d{2})\.\s+(\d{2}\/\d{2}\/\d{2})\s+([\d:]+\s*[AP]M)/;
    const m = raw.trim().match(re);
    if (!m) return null;
    return {
      amount: m[1].replace(/,/g,""),
      senderPhone: m[2],
      transactionId: m[3],
      fee: m[4].replace(/,/g,""),
      balance: m[5].replace(/,/g,""),
      date: m[6],
      time: m[7],
    };
  }

  const handleParse = () => {
    setError(""); setParsed(null);
    if (!text.trim()) { setError("Paste an SMS first"); return; }
    setBusy(true);
    setTimeout(() => {
      const p = parse(text);
      if (!p) { setError("Couldn't parse this SMS. Make sure it's the standard bKash Cash Out format."); setBusy(false); return; }
      setParsed(p); setBusy(false);
    }, 500);
  };

  const handleConfirm = () => {
    if (role === "admin" && !agentId) { setError("Select an agent first"); return; }
    onParsed(parsed, text, agentId);
    setText(""); setParsed(null);
  };

  const filteredAgents = activeAgents.filter(a =>
    !agentSearch || a.name.toLowerCase().includes(agentSearch.toLowerCase()) || a.phone.includes(agentSearch)
  );

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="page-head">
        <div>
          <h1 className="page-title">Upload SMS</h1>
          <div className="page-sub">
            {role === "admin"
              ? "Paste a Cash Out SMS — pick which agent it belongs to and we'll add it to their ledger."
              : "Paste a bKash Cash Out SMS — we'll extract the details and add it to your ledger."}
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 14 }}>
        <div className="card card-pad">
          {role === "admin" ? (
            <div style={{ marginBottom: 18 }}>
              <label className="label">Assign to agent</label>
              <div style={{ position: "relative" }}>
                <button
                  onClick={() => setAgentPickerOpen(o => !o)}
                  className="input"
                  style={{ display: "flex", alignItems: "center", gap: 10, textAlign: "left", cursor: "pointer", padding: "8px 12px" }}>
                  {selectedAgent ? (
                    <>
                      <div className="avatar" style={{ width: 22, height: 22, fontSize: 9 }}>
                        {selectedAgent.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{selectedAgent.name}</div>
                        <div style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>{fmtPhone(selectedAgent.phone)}</div>
                      </div>
                    </>
                  ) : (
                    <span style={{ color: "var(--text-muted)", flex: 1 }}>Select an agent…</span>
                  )}
                  <Icon name="chevron-down" size={13} style={{ color: "var(--text-muted)", transition: "transform 0.15s", transform: agentPickerOpen ? "rotate(180deg)" : "" }} />
                </button>

                {agentPickerOpen && (
                  <>
                    <div style={{ position: "fixed", inset: 0, zIndex: 30 }} onClick={() => setAgentPickerOpen(false)} />
                    <div style={{
                      position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0,
                      background: "var(--surface)", border: "1px solid var(--border)",
                      borderRadius: "var(--r-md)", boxShadow: "var(--shadow-lg)",
                      zIndex: 40, maxHeight: 320, display: "flex", flexDirection: "column"
                    }}>
                      <div style={{ padding: 8, borderBottom: "1px solid var(--divider)", position: "relative" }}>
                        <Icon name="search" size={13} style={{ position: "absolute", left: 18, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
                        <input
                          className="input"
                          style={{ paddingLeft: 30, fontSize: 12 }}
                          placeholder="Search agent…"
                          value={agentSearch}
                          onChange={e => setAgentSearch(e.target.value)}
                          autoFocus
                        />
                      </div>
                      <div style={{ overflowY: "auto", padding: 4 }}>
                        {filteredAgents.length === 0 && (
                          <div style={{ padding: 16, textAlign: "center", fontSize: 12, color: "var(--text-muted)" }}>
                            No agents match
                          </div>
                        )}
                        {filteredAgents.map(a => (
                          <div key={a.id}
                            onClick={() => { setAgentId(a.id); setAgentPickerOpen(false); setAgentSearch(""); }}
                            style={{
                              padding: "8px 10px", borderRadius: "var(--r-sm)",
                              display: "flex", alignItems: "center", gap: 10,
                              cursor: "pointer",
                              background: a.id === agentId ? "var(--surface-2)" : "transparent",
                            }}
                            onMouseEnter={e => { if (a.id !== agentId) e.currentTarget.style.background = "var(--hover)"; }}
                            onMouseLeave={e => { if (a.id !== agentId) e.currentTarget.style.background = "transparent"; }}>
                            <div className="avatar" style={{ width: 22, height: 22, fontSize: 9 }}>
                              {a.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
                            </div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontSize: 13 }}>{a.name}</div>
                              <div style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>{fmtPhone(a.phone)}</div>
                            </div>
                            {a.id === agentId && <Icon name="check" size={13} style={{ color: "var(--brand)" }} />}
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 6, display: "flex", alignItems: "center", gap: 5 }}>
                <Icon name="info" size={11} /> The transaction will be added to <b style={{ color: "var(--text-2)" }}>{selectedAgent?.name || "—"}</b>'s ledger.
              </div>
            </div>
          ) : (
            <div style={{ marginBottom: 18, padding: 12, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-sm)", display: "flex", alignItems: "center", gap: 10 }}>
              <div className="avatar" style={{ width: 26, height: 26 }}>
                {currentUser.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, color: "var(--text-muted)" }}>Uploading to your ledger</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{currentUser.name}</div>
              </div>
              <span className="pill pill-muted"><span className="pill-dot" />You</span>
            </div>
          )}

          <label className="label">SMS message</label>
          <textarea
            className="input"
            style={{ minHeight: 180, fontFamily: "var(--font-mono)", fontSize: 13, lineHeight: 1.6, resize: "vertical" }}
            placeholder={"Cash Out Tk 1,500.00 from 01711223344 successful. TrxID A2B3C4D5E6. Fee Tk 15.00. Balance Tk 5,000.00. 13/05/26 2:30 PM"}
            value={text}
            onChange={e => { setText(e.target.value); setError(""); }}
          />
          {error && <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 8, display: "flex", alignItems: "center", gap: 6 }}><Icon name="alert" size={13} />{error}</div>}

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, gap: 10 }}>
            <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{text.length} characters</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn" onClick={() => { setText(""); setParsed(null); setError(""); }}>Clear</button>
              <button className="btn btn-primary" onClick={handleParse} disabled={busy || !text.trim()} style={{ opacity: (busy || !text.trim()) ? 0.6 : 1 }}>
                <Icon name="zap" size={13} /> {busy ? "Parsing…" : "Parse SMS"}
              </button>
            </div>
          </div>

          {parsed && (
            <div style={{ marginTop: 22, padding: 18, background: "var(--success-soft)", border: "1px solid rgba(52,211,153,0.22)", borderRadius: "var(--r-md)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, color: "var(--success)", fontWeight: 500, marginBottom: 12, fontSize: 13 }}>
                <Icon name="check-circle" size={14} /> Parsed successfully
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px 18px", fontSize: 12 }}>
                {[
                  ["Amount", fmtAmount(parsed.amount)],
                  ["TrxID", parsed.transactionId, "mono"],
                  ["From", fmtPhone(parsed.senderPhone), "mono"],
                  ["Fee", fmtAmount(parsed.fee)],
                  ["Balance after", fmtAmount(parsed.balance)],
                  ["Date/Time", parsed.date + " " + parsed.time],
                ].map(([l,v,cls]) => (
                  <div key={l}>
                    <div style={{ color: "var(--text-muted)", fontSize: 11 }}>{l}</div>
                    <div className={cls || ""} style={{ marginTop: 2, fontWeight: 500 }}>{v}</div>
                  </div>
                ))}
              </div>
              <button className="btn btn-primary" style={{ marginTop: 14, width: "100%", justifyContent: "center" }} onClick={handleConfirm}>
                <Icon name="check" size={13} /> Confirm & add to ledger
              </button>
            </div>
          )}
        </div>

        <div>
          <div className="card card-pad">
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 10 }}>
              <Icon name="info" size={14} style={{ color: "var(--info)" }} />
              <div style={{ fontSize: 13, fontWeight: 500 }}>Sample SMS</div>
            </div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 12 }}>Click to try one</div>
            {SAMPLES.map((s, i) => (
              <div key={i} onClick={() => { setText(s); setParsed(null); setError(""); }}
                style={{ padding: 10, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-sm)", fontSize: 11, fontFamily: "var(--font-mono)", lineHeight: 1.5, marginBottom: 8, cursor: "pointer", color: "var(--text-2)", transition: "background 0.1s" }}
                onMouseEnter={e => e.currentTarget.style.background = "var(--surface-3)"}
                onMouseLeave={e => e.currentTarget.style.background = "var(--surface-2)"}>
                {s}
              </div>
            ))}
          </div>

          <div className="card card-pad" style={{ marginTop: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>How it works</div>
            <ol style={{ paddingLeft: 18, margin: 0, fontSize: 12, color: "var(--text-2)", lineHeight: 1.7 }}>
              <li>Receive the Cash Out SMS on the agent SIM</li>
              <li>Forward or paste it here</li>
              <li>We parse amount, sender, TrxID, fee and balance</li>
              <li>Status starts as <StatusBadge status="received" size="sm" /></li>
              <li>Mark <StatusBadge status="paid" size="sm" /> after handing over cash</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { TransactionList, TransactionDrawer, UploadPage, Pagination });
