// ─── Main App / Router ───────────────────────────────────────────────────────
const { useState, useEffect, useCallback } = React;

function App() {
  // Auth
  const [authed, setAuthed] = useState(() => localStorage.getItem("bk_authed") === "1");
  const [role, setRole] = useState(() => localStorage.getItem("bk_role") || "admin");
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("bk_user");
    if (stored) try { return JSON.parse(stored); } catch (e) {}
    return window.ADMIN;
  });

  // Route
  const [route, setRoute] = useState(() => {
    const h = window.location.hash.slice(1);
    return h || (authed ? "dashboard" : "login");
  });

  useEffect(() => {
    window.location.hash = route;
  }, [route]);

  useEffect(() => {
    const handler = () => {
      const h = window.location.hash.slice(1);
      if (h) setRoute(h);
    };
    window.addEventListener("hashchange", handler);
    return () => window.removeEventListener("hashchange", handler);
  }, []);

  // Theme
  const [theme, setTheme] = useState(() => localStorage.getItem("bk_theme") || "dark");
  useEffect(() => {
    document.documentElement.className = theme === "light" ? "light" : "";
    localStorage.setItem("bk_theme", theme);
  }, [theme]);

  // Sidebar collapse
  const [collapsed, setCollapsed] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState([]);
  const toast = useCallback((type, msg) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(t => [...t, { id, type, msg }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4000);
  }, []);

  // Live transactions (simulate stream)
  const [liveCount, setLiveCount] = useState(7);
  useEffect(() => {
    if (!authed) return;
    const t = setInterval(() => {
      if (Math.random() > 0.7) {
        // Add a new transaction
        const agent = window.AGENTS.filter(a => a.isActive)[Math.floor(Math.random() * window.AGENTS.filter(a => a.isActive).length)];
        const amt = Math.floor(200 + Math.random() * 8000);
        const newTx = {
          id: "tx-live-" + Date.now(),
          transactionId: window.randomTrxId(),
          amount: amt.toFixed(2),
          fee: (amt * 0.0185).toFixed(2),
          balance: (3000 + Math.random()*40000).toFixed(2),
          transactionTime: new Date().toISOString(),
          status: "received",
          agentId: agent.id,
          agentName: agent.name,
          agentPhone: agent.phone,
          senderPhone: window.randomPhone(Date.now()),
          receiverPhone: agent.phone,
          rawMessage: "",
          createdAt: new Date().toISOString(),
          isNew: true,
        };
        newTx.rawMessage = `Cash Out Tk ${amt.toFixed(2)} from ${newTx.senderPhone} successful. TrxID ${newTx.transactionId}. Fee Tk ${newTx.fee}. Balance Tk ${newTx.balance}. ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`;
        window.TRANSACTIONS.unshift(newTx);
        setLiveCount(c => c + 1);
        toast("info", `New transaction · ৳ ${amt.toLocaleString()} from ${newTx.senderPhone.slice(-4)}`);
      }
    }, 12000);
    return () => clearInterval(t);
  }, [authed]);

  // Drawer (transaction detail)
  const [drawerTx, setDrawerTx] = useState(null);

  const markPaid = useCallback((txId) => {
    window.TRANSACTIONS = window.TRANSACTIONS.map(t =>
      t.id === txId ? { ...t, status: "paid", updatedAt: new Date().toISOString() } : t
    );
    toast("success", "Marked as paid");
    setRoute(r => r); // force re-render
  }, [toast]);
  useEffect(() => { window._markPaid = markPaid; }, [markPaid]);

  // Auth handlers
  const handleLogin = () => {
    setAuthed(true);
    localStorage.setItem("bk_authed", "1");
    setRoute("dashboard");
    toast("success", "Welcome back, " + user.name.split(" ")[0]);
  };
  const handleLogout = () => {
    setAuthed(false);
    localStorage.removeItem("bk_authed");
    setRoute("login");
    toast("info", "Signed out");
  };

  // Role switch
  const switchRole = (r) => {
    setRole(r);
    localStorage.setItem("bk_role", r);
    // Update user
    if (r === "admin") {
      setUser(window.ADMIN);
      localStorage.setItem("bk_user", JSON.stringify(window.ADMIN));
    } else {
      const top = [...window.AGENTS].filter(a => a.isActive).sort((a,b) => b.totalPaid - a.totalPaid)[0];
      setUser(top);
      localStorage.setItem("bk_user", JSON.stringify(top));
    }
    // Redirect to dashboard
    setRoute("dashboard");
    toast("info", `Switched to ${r} view`);
  };

  if (!authed) {
    return (
      <>
        <Login onLogin={handleLogin} />
        <Toasts toasts={toasts} />
      </>
    );
  }

  // Page rendering
  const renderPage = () => {
    if (route.startsWith("agent-detail:")) {
      const id = route.split(":")[1];
      return <AgentDetail agentId={id} onBack={() => setRoute("agents")} onOpenTransaction={setDrawerTx} toast={toast} />;
    }
    switch (route) {
      case "dashboard": return <Dashboard role={role} currentUser={user} onNavigate={setRoute} onOpenTransaction={setDrawerTx} liveCount={liveCount} />;
      case "transactions": return <TransactionList role="admin" currentUser={user} onOpenTransaction={setDrawerTx} onNavigate={setRoute} />;
      case "my-transactions": return <TransactionList role="agent" currentUser={user} onOpenTransaction={setDrawerTx} onNavigate={setRoute} />;
      case "upload": return <UploadPage currentUser={user} role={role} onParsed={(parsed, raw, chosenAgentId) => {
        const agentId = role === "admin" ? (chosenAgentId || window.AGENTS[0].id) : user.id;
        const agent = window.AGENTS.find(a => a.id === agentId) || user;
        const newTx = {
          id: "tx-up-" + Date.now(),
          transactionId: parsed.transactionId,
          amount: parsed.amount,
          fee: parsed.fee,
          balance: parsed.balance,
          transactionTime: new Date().toISOString(),
          status: "received",
          agentId,
          agentName: agent.name,
          agentPhone: agent.phone,
          senderPhone: parsed.senderPhone,
          receiverPhone: agent.phone,
          rawMessage: raw,
          createdAt: new Date().toISOString(),
        };
        window.TRANSACTIONS.unshift(newTx);
        toast("success", `Added ${parsed.transactionId} · ${window.fmtAmount(parsed.amount)} to ${agent.name}'s ledger`);
        setRoute("transactions");
      }} />;
      case "agents": return <AgentList onOpenAgent={(id) => setRoute("agent-detail:" + id)} toast={toast} />;
      case "reports": return <ReportsPage role="admin" currentUser={user} onOpenAgent={(id) => setRoute("agent-detail:" + id)} />;
      case "my-reports": return <ReportsPage role="agent" currentUser={user} onOpenAgent={() => {}} />;
      case "settings": return <SettingsPage currentUser={user} onUpdate={(u) => { const updated = {...user, ...u}; setUser(updated); localStorage.setItem("bk_user", JSON.stringify(updated)); }} theme={theme} onToggleTheme={() => setTheme(t => t === "dark" ? "light" : "dark")} toast={toast} />;
      default: return <Dashboard role={role} currentUser={user} onNavigate={setRoute} onOpenTransaction={setDrawerTx} liveCount={liveCount} />;
    }
  };

  const titles = {
    "dashboard": ["Dashboard", role === "admin" ? "Overview across all agents" : "Your personal overview"],
    "transactions": ["Transactions", "All cash-out transactions across the platform"],
    "my-transactions": ["My Transactions", "Transactions assigned to you"],
    "upload": ["Upload SMS", "Add a new transaction from a bKash Cash Out SMS"],
    "agents": ["Agents", "Manage the agent roster"],
    "reports": ["Reports", "Performance analytics and exports"],
    "my-reports": ["My Reports", "Your performance summary"],
    "settings": ["Settings", "Account and preferences"],
  };
  let titleKey = route;
  if (route.startsWith("agent-detail")) titleKey = "agents";
  const [title, subtitle] = titles[titleKey] || ["", ""];

  // Compute current nav highlight key
  let currentPath = route;
  if (route.startsWith("agent-detail")) currentPath = "agents";

  return (
    <div className={"app" + (collapsed ? " collapsed" : "")}>
      <Sidebar
        currentPath={currentPath}
        onNavigate={setRoute}
        collapsed={collapsed}
        onCollapseToggle={() => setCollapsed(!collapsed)}
        role={role}
        user={user}
        onLogout={handleLogout}
      />
      <div className="main">
        <Topbar
          title={title}
          subtitle={subtitle}
          theme={theme}
          onToggleTheme={() => setTheme(t => t === "dark" ? "light" : "dark")}
          onSwitchRole={switchRole}
          role={role}
        />
        {renderPage()}
      </div>

      {drawerTx && <TransactionDrawer tx={drawerTx} onClose={() => setDrawerTx(null)} onMarkPaid={markPaid} />}

      <Toasts toasts={toasts} />
    </div>
  );
}

const Toasts = ({ toasts }) => (
  <div className="toast-wrap">
    {toasts.map(t => (
      <div key={t.id} className={"toast " + t.type}>
        <Icon name={t.type === "success" ? "check-circle" : t.type === "error" ? "alert" : "info"} className="toast-icon" />
        <span>{t.msg}</span>
      </div>
    ))}
  </div>
);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
