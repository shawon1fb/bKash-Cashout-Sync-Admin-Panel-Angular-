// ─── Admin Dashboard ─────────────────────────────────────────────────────────
const Dashboard = ({ role, currentUser, onNavigate, onOpenTransaction, liveCount }) => {
  if (role === "agent") return <AgentDashboard currentUser={currentUser} onOpenTransaction={onOpenTransaction} />;
  return <AdminDashboard onNavigate={onNavigate} onOpenTransaction={onOpenTransaction} liveCount={liveCount} />;
};

const AdminDashboard = ({ onNavigate, onOpenTransaction, liveCount }) => {
  const txAll = window.TRANSACTIONS;
  const paid = txAll.filter(t => t.status === "paid");
  const received = txAll.filter(t => t.status === "received");

  const totalPaid = paid.reduce((s, t) => s + parseFloat(t.amount), 0);
  const totalReceived = received.reduce((s, t) => s + parseFloat(t.amount), 0);
  const totalAgents = window.AGENTS.filter(a => a.isActive).length;

  const daily = dailySeries(txAll, 14);
  const monthly = monthlySeries(txAll, 6);
  const recent = txAll.slice(0, 8);
  const recentAgents = [...window.AGENTS].sort((a,b) => b.totalPaid - a.totalPaid).slice(0, 5);

  const heatmapData = dailySeries(txAll, 49);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <h1 className="page-title">Overview</h1>
            <span className="pill pill-success" style={{ fontSize: 11 }}><span className="live-dot" />Live · {liveCount} new today</span>
          </div>
          <div className="page-sub">{fmtDate(new Date().toISOString(), false)} — Across all agents</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn"><Icon name="download" size={13} /> Export</button>
          <button className="btn btn-primary" onClick={() => onNavigate("upload")}><Icon name="plus" size={13} /> Upload SMS</button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <StatCard label="Total paid amount" value={fmtAmountShort(totalPaid).replace("৳ ","")} currency
          trend="+12.4% vs last month" trendDir="up" icon="wallet"
          sparkData={daily.slice(-12).map(d => d.paidAmount)} />
        <StatCard label="Total transactions" value={txAll.length.toLocaleString()}
          trend={`+${liveCount} today`} trendDir="up" icon="transactions"
          sparkData={daily.slice(-12).map(d => d.count)} />
        <StatCard label="Active agents" value={totalAgents}
          trend={`${window.AGENTS.length - totalAgents} inactive`} trendDir="down" icon="agents" />
        <StatCard label="Pending (received)" value={received.length} currency={false}
          trend={fmtAmountShort(totalReceived)} icon="clock"
          sparkData={daily.slice(-12).map(d => d.receivedCount)} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.65fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Daily volume</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Paid amount, last 14 days</div>
            </div>
            <div className="seg">
              <button className="on">14d</button>
              <button>30d</button>
              <button>90d</button>
            </div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <LineAreaChart data={daily} height={240} valueKey="paidAmount" labelKey="shortLabel" />
          </div>
        </div>

        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Status split</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{txAll.length} total transactions</div>
          </div>
          <div style={{ padding: 20, display: "grid", placeItems: "center" }}>
            <DonutChart
              segments={[
                { label: "Paid", value: paid.length, color: "var(--success)" },
                { label: "Received", value: received.length, color: "var(--warning)" },
              ]}
              centerLabel="Total"
              centerValue={txAll.length}
              size={170}
            />
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px 0", display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Monthly revenue</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Last 6 months</div>
            </div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <BarChart data={monthly} height={210} valueKey="paidAmount" labelKey="label" />
          </div>
        </div>

        <div className="card">
          <div style={{ padding: "16px 20px 0", display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Transaction activity</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Last 7 weeks · darker = busier</div>
            </div>
            <div style={{ fontSize: 11, color: "var(--text-dim)" }}>
              <span style={{ display: "inline-block", width: 10, height: 10, background: "var(--surface-2)", borderRadius: 2, marginRight: 4, verticalAlign: "middle" }}></span>0
              <span style={{ display: "inline-block", width: 10, height: 10, background: "var(--brand)", borderRadius: 2, marginRight: 4, marginLeft: 6, verticalAlign: "middle" }}></span>max
            </div>
          </div>
          <div style={{ padding: 20, display: "grid", placeItems: "center" }}>
            <Heatmap data={heatmapData} days={49} />
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--divider)" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Recent transactions</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Latest activity across all agents</div>
            </div>
            <button className="btn btn-sm btn-ghost" onClick={() => onNavigate("transactions")}>View all <Icon name="arrow-right" size={12} /></button>
          </div>
          <div style={{ overflow: "auto" }}>
            <table className="tbl">
              <thead><tr>
                <th>TrxID</th>
                <th>Agent</th>
                <th className="tbl-num">Amount</th>
                <th>Status</th>
                <th>Time</th>
              </tr></thead>
              <tbody>
                {recent.map(t => (
                  <tr key={t.id} onClick={() => onOpenTransaction(t)}>
                    <td><span className="mono" style={{ fontSize: 12 }}>{t.transactionId}</span></td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div className="avatar" style={{ width: 22, height: 22, fontSize: 9 }}>{t.agentName.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
                        <span style={{ fontSize: 13 }}>{t.agentName.split(" ")[0]}</span>
                      </div>
                    </td>
                    <td className="tbl-num mono">{fmtAmount(t.amount)}</td>
                    <td><StatusBadge status={t.status} /></td>
                    <td style={{ color: "var(--text-muted)", fontSize: 12 }}>{fmtRelative(t.transactionTime)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--divider)" }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Top agents</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>By paid amount</div>
            </div>
            <button className="btn btn-sm btn-ghost" onClick={() => onNavigate("agents")}>All agents <Icon name="arrow-right" size={12} /></button>
          </div>
          <div style={{ padding: 14 }}>
            {recentAgents.map((a, i) => {
              const max = recentAgents[0].totalPaid;
              return (
                <div key={a.id} style={{ padding: "10px 8px", borderBottom: i < recentAgents.length-1 ? "1px solid var(--divider)" : "none", cursor: "pointer" }} onClick={() => onNavigate("agent-detail:" + a.id)}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                    <div className="avatar" style={{ background: `hsl(${(i*67) % 360}, 60%, 55%)` }}>
                      {a.name.split(" ").map(s=>s[0]).slice(0,2).join("")}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{a.name}</div>
                      <div style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>{fmtPhone(a.phone)}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div className="mono" style={{ fontSize: 13, fontWeight: 500 }}>{fmtAmountShort(a.totalPaid)}</div>
                      <div style={{ fontSize: 10, color: "var(--text-muted)" }}>{a.totalCount} txns</div>
                    </div>
                  </div>
                  <MiniBar value={a.totalPaid} max={max} />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

const AgentDashboard = ({ currentUser, onOpenTransaction }) => {
  const txAll = window.TRANSACTIONS.filter(t => t.agentId === currentUser.id);
  const today = new Date(); today.setHours(0,0,0,0);
  const week = new Date(today); week.setDate(week.getDate() - 7);
  const month = new Date(today); month.setMonth(month.getMonth() - 1);

  const todayTx = txAll.filter(t => new Date(t.transactionTime) >= today);
  const weekTx = txAll.filter(t => new Date(t.transactionTime) >= week);
  const monthTx = txAll.filter(t => new Date(t.transactionTime) >= month);
  const todayPaid = todayTx.filter(t => t.status === "paid").reduce((s,t) => s+parseFloat(t.amount), 0);
  const weekPaid = weekTx.filter(t => t.status === "paid").reduce((s,t) => s+parseFloat(t.amount), 0);
  const monthPaid = monthTx.filter(t => t.status === "paid").reduce((s,t) => s+parseFloat(t.amount), 0);

  const daily = dailySeries(txAll, 14);
  const paidCount = txAll.filter(t => t.status === "paid").length;
  const recvCount = txAll.filter(t => t.status === "received").length;
  const recent = txAll.slice(0, 8);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">Welcome, {currentUser.name.split(" ")[0]}</h1>
          <div className="page-sub">{fmtDate(new Date().toISOString(), false)} — Your activity at a glance</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <StatCard label="Today paid" value={fmtAmountShort(todayPaid).replace("৳ ","")} currency icon="wallet" trend={`${todayTx.length} txns`} trendDir="up" />
        <StatCard label="This week" value={fmtAmountShort(weekPaid).replace("৳ ","")} currency icon="trending-up" sparkData={daily.slice(-7).map(d=>d.paidAmount)} />
        <StatCard label="This month" value={fmtAmountShort(monthPaid).replace("৳ ","")} currency icon="trending-up" trend="+8.2%" trendDir="up" />
        <StatCard label="Today txns" value={todayTx.length} icon="transactions" trend={`${todayTx.filter(t=>t.status==="received").length} pending`} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.65fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Daily earnings</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Last 14 days</div>
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <LineAreaChart data={daily} height={220} valueKey="paidAmount" labelKey="shortLabel" />
          </div>
        </div>
        <div className="card">
          <div style={{ padding: "16px 20px 0" }}>
            <div style={{ fontSize: 13, fontWeight: 500 }}>By status</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{txAll.length} total</div>
          </div>
          <div style={{ padding: 20, display: "grid", placeItems: "center" }}>
            <DonutChart
              segments={[
                { label: "Paid", value: paidCount, color: "var(--success)" },
                { label: "Received", value: recvCount, color: "var(--warning)" },
              ]}
              centerLabel="Txns"
              centerValue={txAll.length}
              size={160}
            />
          </div>
        </div>
      </div>

      <div className="card">
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--divider)" }}>
          <div style={{ fontSize: 13, fontWeight: 500 }}>My recent transactions</div>
        </div>
        <table className="tbl">
          <thead><tr>
            <th>TrxID</th>
            <th>Sender</th>
            <th className="tbl-num">Amount</th>
            <th>Status</th>
            <th>Time</th>
          </tr></thead>
          <tbody>
            {recent.map(t => (
              <tr key={t.id} onClick={() => onOpenTransaction(t)}>
                <td><span className="mono" style={{ fontSize: 12 }}>{t.transactionId}</span></td>
                <td className="mono" style={{ fontSize: 12 }}>{fmtPhone(t.senderPhone)}</td>
                <td className="tbl-num mono">{fmtAmount(t.amount)}</td>
                <td><StatusBadge status={t.status} /></td>
                <td style={{ color: "var(--text-muted)", fontSize: 12 }}>{fmtRelative(t.transactionTime)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

Object.assign(window, { Dashboard, AdminDashboard, AgentDashboard });
