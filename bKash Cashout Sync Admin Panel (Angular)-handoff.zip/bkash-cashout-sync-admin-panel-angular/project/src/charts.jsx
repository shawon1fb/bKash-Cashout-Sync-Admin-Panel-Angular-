// ─── Custom SVG charts (no library) ──────────────────────────────────────────
// Themed via CSS vars; responsive (uses ResizeObserver).

const useSize = (ref) => {
  const [size, setSize] = React.useState({ w: 600, h: 240 });
  React.useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(entries => {
      for (const e of entries) {
        const cr = e.contentRect;
        setSize({ w: Math.max(220, cr.width), h: cr.height || 240 });
      }
    });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  return size;
};

// ─── Line / Area chart ───────────────────────────────────────────────────────
const LineAreaChart = ({ data, height = 240, color = "var(--brand)", color2 = "var(--brand-2)", valueKey = "paidAmount", labelKey = "label", currency = true, area = true, smooth = true }) => {
  const ref = React.useRef(null);
  const { w } = useSize(ref);
  const h = height;
  const [hover, setHover] = React.useState(null);
  const padL = 44, padR = 14, padT = 16, padB = 30;

  const values = data.map(d => d[valueKey]);
  const max = Math.max(...values, 1);
  const min = 0;
  const stepX = (w - padL - padR) / Math.max(data.length - 1, 1);
  const x = (i) => padL + i * stepX;
  const y = (v) => padT + (1 - (v - min) / (max - min || 1)) * (h - padT - padB);

  // Smooth path (catmull-rom-ish)
  function makePath(close) {
    let path = "";
    data.forEach((d, i) => {
      const px = x(i), py = y(d[valueKey]);
      if (i === 0) path += `M ${px},${py}`;
      else if (smooth) {
        const prevX = x(i-1), prevY = y(data[i-1][valueKey]);
        const cx = (prevX + px) / 2;
        path += ` C ${cx},${prevY} ${cx},${py} ${px},${py}`;
      } else path += ` L ${px},${py}`;
    });
    if (close) path += ` L ${x(data.length-1)},${h-padB} L ${x(0)},${h-padB} Z`;
    return path;
  }

  // Y axis ticks
  const ticks = 4;
  const tickVals = [];
  for (let i = 0; i <= ticks; i++) tickVals.push(min + (max - min) * (i / ticks));

  const fmt = (v) => currency ? (typeof window.fmtAmountShort === "function" ? window.fmtAmountShort(v) : v) : Math.round(v);

  return (
    <div ref={ref} style={{ width: "100%", position: "relative" }}>
      <svg width={w} height={h} style={{ display: "block" }}>
        <defs>
          <linearGradient id="lac-area" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28"/>
            <stop offset="100%" stopColor={color} stopOpacity="0"/>
          </linearGradient>
          <linearGradient id="lac-line" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor={color}/>
            <stop offset="100%" stopColor={color2}/>
          </linearGradient>
        </defs>
        {/* Grid */}
        {tickVals.map((v, i) => (
          <g key={i}>
            <line x1={padL} x2={w - padR} y1={y(v)} y2={y(v)} stroke="var(--divider)" strokeDasharray="2 4" />
            <text x={padL - 8} y={y(v) + 4} fontSize="10" fill="var(--text-dim)" textAnchor="end">{fmt(v)}</text>
          </g>
        ))}
        {/* X labels */}
        {data.map((d, i) => (
          <text key={i} x={x(i)} y={h - padB + 16} fontSize="10" fill="var(--text-muted)" textAnchor="middle">{d[labelKey]}</text>
        ))}
        {/* Area */}
        {area && <path d={makePath(true)} fill="url(#lac-area)" />}
        {/* Line */}
        <path d={makePath(false)} fill="none" stroke="url(#lac-line)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {/* Points */}
        {data.map((d, i) => (
          <g key={i}>
            <circle cx={x(i)} cy={y(d[valueKey])} r={hover === i ? 5 : 3} fill="var(--surface)" stroke={color} strokeWidth="2" style={{ transition: "r 0.12s" }} />
          </g>
        ))}
        {/* Hover hit areas */}
        {data.map((d, i) => (
          <rect key={i} x={x(i) - stepX/2} y={padT} width={stepX} height={h - padT - padB}
            fill="transparent"
            onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
        ))}
        {hover != null && (
          <g>
            <line x1={x(hover)} x2={x(hover)} y1={padT} y2={h-padB} stroke={color} strokeDasharray="3 3" strokeOpacity="0.4" />
          </g>
        )}
      </svg>
      {hover != null && (
        <div style={{ position: "absolute", left: Math.min(x(hover) + 10, w - 160), top: y(data[hover][valueKey]) - 18, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--r-sm)", padding: "8px 10px", fontSize: 12, boxShadow: "var(--shadow-md)", pointerEvents: "none", whiteSpace: "nowrap" }}>
          <div style={{ color: "var(--text-muted)", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>{data[hover][labelKey]}</div>
          <div style={{ fontWeight: 600, marginTop: 2, fontFamily: "var(--font-mono)" }}>{fmt(data[hover][valueKey])}</div>
        </div>
      )}
    </div>
  );
};

// ─── Bar chart ───────────────────────────────────────────────────────────────
const BarChart = ({ data, height = 240, color = "var(--brand)", valueKey = "paidAmount", labelKey = "label", currency = true }) => {
  const ref = React.useRef(null);
  const { w } = useSize(ref);
  const h = height;
  const [hover, setHover] = React.useState(null);
  const padL = 44, padR = 14, padT = 16, padB = 30;
  const values = data.map(d => d[valueKey]);
  const max = Math.max(...values, 1);
  const stepX = (w - padL - padR) / data.length;
  const barW = Math.max(8, stepX * 0.6);
  const y = (v) => padT + (1 - v / max) * (h - padT - padB);

  const ticks = 4;
  const tickVals = [];
  for (let i = 0; i <= ticks; i++) tickVals.push(max * (i / ticks));
  const fmt = (v) => currency ? (typeof window.fmtAmountShort === "function" ? window.fmtAmountShort(v) : v) : Math.round(v);

  return (
    <div ref={ref} style={{ width: "100%", position: "relative" }}>
      <svg width={w} height={h} style={{ display: "block" }}>
        <defs>
          <linearGradient id="bar-grad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.95"/>
            <stop offset="100%" stopColor={color} stopOpacity="0.55"/>
          </linearGradient>
          <linearGradient id="bar-grad-hover" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="var(--brand-2)" stopOpacity="1"/>
            <stop offset="100%" stopColor={color} stopOpacity="0.7"/>
          </linearGradient>
        </defs>
        {tickVals.map((v, i) => (
          <g key={i}>
            <line x1={padL} x2={w-padR} y1={y(v)} y2={y(v)} stroke="var(--divider)" strokeDasharray="2 4"/>
            <text x={padL - 8} y={y(v)+4} fontSize="10" fill="var(--text-dim)" textAnchor="end">{fmt(v)}</text>
          </g>
        ))}
        {data.map((d, i) => {
          const cx = padL + stepX * i + stepX/2;
          const by = y(d[valueKey]);
          return (
            <g key={i}>
              <rect x={cx - barW/2} y={by} width={barW} height={h - padB - by} rx="3"
                fill={hover === i ? "url(#bar-grad-hover)" : "url(#bar-grad)"}
                onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
                style={{ transition: "fill 0.15s" }} />
              <text x={cx} y={h - padB + 16} fontSize="10" fill="var(--text-muted)" textAnchor="middle">{d[labelKey]}</text>
            </g>
          );
        })}
      </svg>
      {hover != null && (
        <div style={{ position: "absolute", left: padL + stepX * hover + stepX/2 + 8, top: y(data[hover][valueKey]) - 4, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--r-sm)", padding: "8px 10px", fontSize: 12, boxShadow: "var(--shadow-md)", pointerEvents: "none", whiteSpace: "nowrap", transform: "translateY(-100%)" }}>
          <div style={{ color: "var(--text-muted)", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>{data[hover][labelKey]}</div>
          <div style={{ fontWeight: 600, marginTop: 2, fontFamily: "var(--font-mono)" }}>{fmt(data[hover][valueKey])}</div>
        </div>
      )}
    </div>
  );
};

// ─── Donut chart ─────────────────────────────────────────────────────────────
const DonutChart = ({ segments, size = 180, thickness = 22, centerLabel, centerValue }) => {
  const r = size/2;
  const inner = r - thickness;
  const total = segments.reduce((s,seg) => s + seg.value, 0) || 1;
  let cur = -Math.PI/2; // top
  function arc(start, end) {
    const x1 = r + r * Math.cos(start);
    const y1 = r + r * Math.sin(start);
    const x2 = r + r * Math.cos(end);
    const y2 = r + r * Math.sin(end);
    const ix1 = r + inner * Math.cos(end);
    const iy1 = r + inner * Math.sin(end);
    const ix2 = r + inner * Math.cos(start);
    const iy2 = r + inner * Math.sin(start);
    const large = end - start > Math.PI ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} L ${ix1} ${iy1} A ${inner} ${inner} 0 ${large} 0 ${ix2} ${iy2} Z`;
  }
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {segments.map((seg, i) => {
          const ang = (seg.value / total) * Math.PI * 2;
          const start = cur, end = cur + ang;
          cur = end;
          return <path key={i} d={arc(start, end)} fill={seg.color} style={{ transition: "opacity 0.15s" }} />;
        })}
        {centerValue && (
          <>
            <text x={r} y={r-4} textAnchor="middle" fontSize="11" fill="var(--text-muted)" style={{ textTransform: "uppercase", letterSpacing: "0.05em" }}>{centerLabel}</text>
            <text x={r} y={r+18} textAnchor="middle" fontSize="22" fontWeight="600" fill="var(--text)" style={{ fontFamily: "var(--font-mono)" }}>{centerValue}</text>
          </>
        )}
      </svg>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {segments.map((seg, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13 }}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: seg.color }} />
            <div>
              <div>{seg.label}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
                {seg.value} <span style={{ opacity: 0.6 }}>({((seg.value/total)*100).toFixed(1)}%)</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Heatmap (calendar) ──────────────────────────────────────────────────────
const Heatmap = ({ data, days = 49 }) => {
  // data: array of {date: Date, count: number}, build from transactions
  const max = Math.max(1, ...data.map(d => d.count));
  const cell = 14, gap = 3;
  const cols = 7; // weeks across (7 days each col)
  const weeks = Math.ceil(days / 7);

  return (
    <div style={{ display: "flex", gap: 2, alignItems: "flex-end" }}>
      <div style={{ display: "flex", flexDirection: "column", gap, paddingRight: 6, fontSize: 9, color: "var(--text-dim)" }}>
        {["M","W","F"].map(d => <div key={d} style={{ height: cell }}>{d}</div>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${weeks}, ${cell}px)`, gridTemplateRows: `repeat(7, ${cell}px)`, gap, gridAutoFlow: "column" }}>
        {data.slice(-days).map((d, i) => {
          const intensity = d.count / max;
          let bg = "var(--surface-2)";
          if (intensity > 0.05) bg = `color-mix(in oklab, var(--brand) ${Math.min(100, 20 + intensity * 80)}%, transparent)`;
          return (
            <div key={i} title={`${d.count} on ${d.date.toLocaleDateString()}`} style={{
              width: cell, height: cell, borderRadius: 3, background: bg, border: "1px solid var(--border)"
            }} />
          );
        })}
      </div>
    </div>
  );
};

// ─── Mini bar (horizontal performance bar) ────────────────────────────────────
const MiniBar = ({ value, max, color = "var(--brand)" }) => (
  <div style={{ width: "100%", height: 5, background: "var(--surface-3)", borderRadius: 3, overflow: "hidden" }}>
    <div style={{ width: `${Math.min(100, (value/(max||1))*100)}%`, height: "100%", background: color, borderRadius: 3 }} />
  </div>
);

Object.assign(window, { LineAreaChart, BarChart, DonutChart, Heatmap, MiniBar });
