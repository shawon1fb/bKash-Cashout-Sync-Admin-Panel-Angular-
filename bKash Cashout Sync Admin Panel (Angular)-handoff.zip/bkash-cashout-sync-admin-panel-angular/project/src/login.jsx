// ─── Login (OTP flow) ─────────────────────────────────────────────────────────
const Login = ({ onLogin }) => {
  const [step, setStep] = React.useState("phone"); // "phone" | "otp"
  const [phone, setPhone] = React.useState("01711223344");
  const [otp, setOtp] = React.useState(["","","","","",""]);
  const [phoneError, setPhoneError] = React.useState("");
  const [otpError, setOtpError] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [secondsLeft, setSecondsLeft] = React.useState(300);
  const [demoOtp, setDemoOtp] = React.useState("");
  const otpRefs = React.useRef([]);

  React.useEffect(() => {
    if (step !== "otp") return;
    if (secondsLeft <= 0) return;
    const t = setInterval(() => setSecondsLeft(s => s - 1), 1000);
    return () => clearInterval(t);
  }, [step, secondsLeft]);

  React.useEffect(() => {
    if (step === "otp") {
      setTimeout(() => otpRefs.current[0]?.focus(), 100);
    }
  }, [step]);

  const phoneOk = /^01[3-9]\d{8}$/.test(phone);

  const sendOtp = () => {
    setPhoneError("");
    if (!phoneOk) { setPhoneError("Enter a valid Bangladeshi number"); return; }
    setLoading(true);
    setTimeout(() => {
      const code = String(Math.floor(100000 + Math.random()*900000));
      setDemoOtp(code);
      setSecondsLeft(300);
      setStep("otp");
      setLoading(false);
    }, 700);
  };

  const verify = () => {
    const code = otp.join("");
    setOtpError("");
    if (code.length !== 6) { setOtpError("Enter all 6 digits"); return; }
    setLoading(true);
    setTimeout(() => {
      if (code === demoOtp || code === "123456") {
        onLogin();
      } else {
        setOtpError("Invalid OTP — try " + demoOtp + " or 123456");
        setLoading(false);
      }
    }, 600);
  };

  const onOtpChange = (i, v) => {
    if (v && !/^\d$/.test(v)) return;
    const next = [...otp];
    next[i] = v;
    setOtp(next);
    if (v && i < 5) otpRefs.current[i+1]?.focus();
    if (i === 5 && v && next.every(x => x)) {
      setTimeout(() => verify(), 100);
    }
  };
  const onOtpKey = (i, e) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) {
      otpRefs.current[i-1]?.focus();
    }
  };
  const onOtpPaste = (e) => {
    const v = e.clipboardData.getData("text").replace(/\D/g, "").slice(0,6);
    if (v.length) {
      e.preventDefault();
      const next = v.padEnd(6, "").split("").slice(0,6);
      while (next.length < 6) next.push("");
      setOtp(next);
      const lastIdx = Math.min(v.length, 5);
      otpRefs.current[lastIdx]?.focus();
    }
  };

  const mm = Math.floor(secondsLeft/60);
  const ss = String(secondsLeft%60).padStart(2,"0");

  return (
    <div className="auth-wrap">
      <div style={{ position: "absolute", top: 24, left: 24, display: "flex", alignItems: "center", gap: 9, fontWeight: 600 }}>
        <div className="brand-glyph" style={{ width: 28, height: 28 }}>b</div>
        <div>
          <div style={{ fontSize: 14, letterSpacing: "-0.01em" }}>Cashout Sync</div>
          <div style={{ fontSize: 10, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Admin Console</div>
        </div>
      </div>

      <div className="auth-card">
        <div style={{ marginBottom: 24 }}>
          {step === "phone" ? (
            <>
              <h1 style={{ fontSize: 22, fontWeight: 600, margin: 0, letterSpacing: "-0.02em" }}>Sign in</h1>
              <p style={{ color: "var(--text-muted)", fontSize: 13, marginTop: 6, marginBottom: 0 }}>
                We'll send a 6-digit code to your bKash-registered number.
              </p>
            </>
          ) : (
            <>
              <h1 style={{ fontSize: 22, fontWeight: 600, margin: 0, letterSpacing: "-0.02em" }}>Enter verification code</h1>
              <p style={{ color: "var(--text-muted)", fontSize: 13, marginTop: 6, marginBottom: 0 }}>
                Sent to <span style={{ color: "var(--text-2)", fontFamily: "var(--font-mono)" }}>{fmtPhone(phone)}</span>
                <button onClick={() => { setStep("phone"); setOtp(["","","","","",""]); }} style={{ marginLeft: 8, color: "var(--brand-2)", fontSize: 12 }}>Change</button>
              </p>
            </>
          )}
        </div>

        {step === "phone" ? (
          <div>
            <label className="label">Phone number</label>
            <div style={{ position: "relative" }}>
              <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 13, color: "var(--text-muted)", pointerEvents: "none" }}>+880</span>
              <input
                className="input"
                style={{ paddingLeft: 50, fontFamily: "var(--font-mono)" }}
                value={phone}
                placeholder="01XXXXXXXXX"
                onChange={e => { setPhone(e.target.value.replace(/\D/g,"").slice(0,11)); setPhoneError(""); }}
                onKeyDown={e => e.key === "Enter" && sendOtp()}
                maxLength={11}
              />
            </div>
            {phoneError && <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 6 }}>{phoneError}</div>}

            <button onClick={sendOtp} disabled={!phoneOk || loading} className="btn btn-primary" style={{ width: "100%", marginTop: 18, justifyContent: "center", padding: "11px 14px", opacity: (!phoneOk || loading) ? 0.6 : 1 }}>
              {loading ? <><span className="skel" style={{ width: 12, height: 12, borderRadius: "50%" }} />Sending…</> : <>Send code <Icon name="arrow-right" size={14} /></>}
            </button>

            <div style={{ marginTop: 22, padding: 12, background: "var(--surface-2)", border: "1px dashed var(--border-strong)", borderRadius: "var(--r-sm)", fontSize: 12, color: "var(--text-muted)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--text-2)", fontWeight: 500, marginBottom: 4 }}>
                <Icon name="info" size={13} /> Demo mode
              </div>
              Any valid BD number works. Use OTP <span style={{ color: "var(--brand-2)", fontFamily: "var(--font-mono)" }}>123456</span> or the one shown next screen.
            </div>
          </div>
        ) : (
          <div>
            <label className="label">6-digit OTP</label>
            <div className="otp-row" onPaste={onOtpPaste}>
              {otp.map((v, i) => (
                <input
                  key={i}
                  ref={el => otpRefs.current[i] = el}
                  className={"otp-cell" + (v ? " filled" : "")}
                  value={v}
                  onChange={e => onOtpChange(i, e.target.value.slice(-1))}
                  onKeyDown={e => onOtpKey(i, e)}
                  maxLength={1}
                  inputMode="numeric"
                />
              ))}
            </div>
            {otpError && <div style={{ color: "var(--danger)", fontSize: 12, marginTop: 8 }}>{otpError}</div>}

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, fontSize: 12 }}>
              <span style={{ color: "var(--text-muted)" }}>
                {secondsLeft > 0 ? <>Expires in <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-2)" }}>{mm}:{ss}</span></> : "Code expired"}
              </span>
              {secondsLeft <= 0 ? (
                <button onClick={sendOtp} style={{ color: "var(--brand-2)", fontWeight: 500 }}>Resend</button>
              ) : (
                <span style={{ color: "var(--text-dim)" }}>Demo OTP: <span style={{ fontFamily: "var(--font-mono)", color: "var(--brand-2)" }}>{demoOtp}</span></span>
              )}
            </div>

            <button onClick={verify} disabled={otp.some(x => !x) || loading} className="btn btn-primary" style={{ width: "100%", marginTop: 18, justifyContent: "center", padding: "11px 14px", opacity: (otp.some(x => !x) || loading) ? 0.6 : 1 }}>
              {loading ? "Verifying…" : <>Verify & sign in <Icon name="check" size={14} /></>}
            </button>
          </div>
        )}

        <div style={{ marginTop: 20, textAlign: "center", fontSize: 11, color: "var(--text-dim)" }}>
          By signing in you agree to the platform terms.
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 18, fontSize: 11, color: "var(--text-dim)", display: "flex", gap: 18 }}>
        <span>v 0.21.4 · Internal build</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><span className="live-dot" /> All systems operational</span>
      </div>
    </div>
  );
};

Object.assign(window, { Login });
